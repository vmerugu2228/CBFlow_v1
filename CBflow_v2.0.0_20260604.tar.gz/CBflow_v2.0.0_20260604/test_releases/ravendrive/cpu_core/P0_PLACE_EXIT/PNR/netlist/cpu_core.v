// Logic netlist
// [TEST MODE]
