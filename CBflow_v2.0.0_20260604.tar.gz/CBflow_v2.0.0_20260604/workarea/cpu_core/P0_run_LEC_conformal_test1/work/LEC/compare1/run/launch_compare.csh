#!/bin/csh -f
# CBflow tool launch wrapper — compare
# Generated: Thu Jun 04 12:23:41 IST 2026
conformal -dofile /Users/vmerugu/projects/CBflow_clone/PD/cmds/LEC/cadence/conformal/v1.0.0/compare_conformal.tcl -logfile /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_LEC_conformal_test1/work/LEC/compare1/run/compare1.log
