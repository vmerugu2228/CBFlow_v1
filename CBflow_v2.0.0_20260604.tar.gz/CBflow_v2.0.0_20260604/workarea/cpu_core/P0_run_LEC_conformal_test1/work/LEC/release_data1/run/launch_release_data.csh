#!/bin/csh -f
# CBflow tool launch wrapper — release_data
# Generated: Thu Jun 04 12:23:44 IST 2026
conformal -dofile /Users/vmerugu/projects/CBflow_clone/PD/cmds/LEC/cadence/conformal/v1.0.0/release_data_conformal.tcl -logfile /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_LEC_conformal_test1/work/LEC/release_data1/run/release_data1.log
