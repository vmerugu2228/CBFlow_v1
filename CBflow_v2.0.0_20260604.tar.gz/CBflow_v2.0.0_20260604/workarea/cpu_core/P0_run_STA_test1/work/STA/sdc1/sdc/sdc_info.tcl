set sdc_info(timestamp) "Wed Jun 03 09:40:55 IST 2026"
set sdc_info(mode_count) 0
