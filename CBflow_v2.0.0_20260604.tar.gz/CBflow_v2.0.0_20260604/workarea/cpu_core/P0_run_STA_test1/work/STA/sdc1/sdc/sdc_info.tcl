set sdc_info(timestamp) "Thu Jun 04 12:31:45 IST 2026"
set sdc_info(mode_count) 0
