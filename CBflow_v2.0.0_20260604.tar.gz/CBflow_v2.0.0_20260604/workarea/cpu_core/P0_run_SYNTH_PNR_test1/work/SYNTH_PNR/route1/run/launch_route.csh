#!/bin/csh -f
# CBFlow tool launch wrapper — SYNTH_PNR route
# Generated: Wed Jun 03 09:41:30 IST 2026
fc_shell -f /Users/vmerugu/projects/CBflow_clone/PD/cmds/SYNTH_PNR/synopsys/fc/v1.0.0/route_fc.tcl -output_log_file /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_SYNTH_PNR_test1/work/SYNTH_PNR/route1/run/route1.log
