#!/bin/csh -f
# CBflow tool launch wrapper — cts_opt
# Generated: Thu Jun 04 12:25:53 IST 2026
fc_shell -f /Users/vmerugu/projects/CBflow_clone/PD/cmds/SYNTH_PNR/synopsys/fc/v1.0.0/cts_opt_fc.tcl -output_log_file /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_SYNTH_PNR_test1/work/SYNTH_PNR/cts_opt1/run/cts_opt1.log
