#!/bin/csh -f
# CBFlow tool launch wrapper — SYNTH_PNR release_data
# Generated: Wed Jun 03 09:41:43 IST 2026
fc_shell -f /Users/vmerugu/projects/CBflow_clone/PD/cmds/SYNTH_PNR/synopsys/fc/v1.0.0/release_data_fc.tcl -output_log_file /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_SYNTH_PNR_test1/work/SYNTH_PNR/release_data1/run/release_data1.log
