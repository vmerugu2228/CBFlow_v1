#!/bin/csh -f
# CBflow tool launch wrapper — signoff
# Generated: Thu Jun 04 12:26:03 IST 2026
fc_shell -f /Users/vmerugu/projects/CBflow_clone/PD/cmds/SYNTH_PNR/synopsys/fc/v1.0.0/signoff_fc.tcl -output_log_file /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_SYNTH_PNR_test1/work/SYNTH_PNR/signoff1/run/signoff1.log
