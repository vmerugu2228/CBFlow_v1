# Output Manifest — SYNTH_PNR export_data1
# Generated: Wed Jun 03 09:41:40 IST 2026
# Design: cpu_core

set manifest(netlist,logic) "/Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_SYNTH_PNR_test1/outputs/cpu_core.v"
set manifest(netlist,pt) "/Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_SYNTH_PNR_test1/outputs/cpu_core.pt.v"
set manifest(netlist,fm) "/Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_SYNTH_PNR_test1/outputs/cpu_core.fm.v"
set manifest(netlist,lvs) "/Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_SYNTH_PNR_test1/outputs/cpu_core.lvs.v"
set manifest(netlist,vc_lp) "/Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_SYNTH_PNR_test1/outputs/cpu_core.vc_lp.v"
set manifest(netlist,dc) "/Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_SYNTH_PNR_test1/outputs/cpu_core.dc.v"
set manifest(gds) "/Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_SYNTH_PNR_test1/outputs/cpu_core.gds"
set manifest(def) "/Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_SYNTH_PNR_test1/outputs/cpu_core.def"
set manifest(lef) "/Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_SYNTH_PNR_test1/outputs/cpu_core.lef"
set manifest(sdc) "/Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_SYNTH_PNR_test1/outputs/cpu_core_func_tt_0p80v_rctyp_25c.sdc"
set manifest(upf) "/Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_SYNTH_PNR_test1/outputs/cpu_core.upf"
set manifest(spef) "/Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_SYNTH_PNR_test1/outputs/cpu_core.spef"
set manifest(wscript) "/Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_SYNTH_PNR_test1/outputs/cpu_core_wscript"
set manifest(wscript_for_pt) "/Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_SYNTH_PNR_test1/outputs/cpu_core_wscript_for_pt"
set manifest(routing_constraints) "/Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_SYNTH_PNR_test1/outputs/cpu_core_routing_constraints"
set manifest(floorplan) "/Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_SYNTH_PNR_test1/outputs/cpu_core_floorplan"
set manifest(saif_ptpx_map) "/Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_SYNTH_PNR_test1/outputs/cpu_core.saif.ptpx.map"
set manifest(saif_fc_map) "/Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_SYNTH_PNR_test1/outputs/cpu_core.saif.fc.map"

set manifest(flow) "SYNTH_PNR"
set manifest(node) "export_data1"
set manifest(design) "cpu_core"
set manifest(run_dir) "/Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_SYNTH_PNR_test1"
set manifest(timestamp) "Wed Jun 03 09:41:40 IST 2026"
set manifest(file_count) 18
