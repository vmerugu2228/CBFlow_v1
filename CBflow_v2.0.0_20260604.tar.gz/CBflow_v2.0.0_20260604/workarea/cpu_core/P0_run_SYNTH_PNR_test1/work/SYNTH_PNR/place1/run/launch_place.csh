#!/bin/csh -f
# CBflow tool launch wrapper — place
# Generated: Thu Jun 04 12:25:47 IST 2026
fc_shell -f /Users/vmerugu/projects/CBflow_clone/PD/cmds/SYNTH_PNR/synopsys/fc/v1.0.0/place_fc.tcl -output_log_file /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_SYNTH_PNR_test1/work/SYNTH_PNR/place1/run/place1.log
