#!/bin/csh -f
# CBFlow tool launch wrapper — SYNTH export_data
# Generated: Wed Jun 03 21:07:24 IST 2026
genus -f /Users/vmerugu/projects/CBflow_clone/PD/cmds/SYNTH/cadence/genus/v1.0.0/export_db_genus.tcl -log /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_SYNTH_genus_test1/work/SYNTH/export_data1/run/export_data1.log
