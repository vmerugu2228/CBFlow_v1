#!/bin/csh -f
# CBflow tool launch wrapper — export_data
# Generated: Thu Jun 04 12:25:33 IST 2026
genus -f /Users/vmerugu/projects/CBflow_clone/PD/cmds/SYNTH/cadence/genus/v1.0.0/export_db_genus.tcl -log /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_SYNTH_genus_test1/work/SYNTH/export_data1/run/export_data1.log
