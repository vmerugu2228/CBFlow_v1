#!/bin/csh -f
# CBflow tool launch wrapper — init_design
# Generated: Thu Jun 04 12:25:26 IST 2026
genus -f /Users/vmerugu/projects/CBflow_clone/PD/cmds/SYNTH/cadence/genus/v1.0.0/init_design_genus.tcl -log /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_SYNTH_genus_test1/work/SYNTH/init_design1/run/init_design1.log
