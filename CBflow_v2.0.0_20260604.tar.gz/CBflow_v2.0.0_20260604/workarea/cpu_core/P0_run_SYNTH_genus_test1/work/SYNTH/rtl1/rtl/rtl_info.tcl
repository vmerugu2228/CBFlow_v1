# RTL Information
set rtl_info(source_files) {/Users/vmerugu/projects/CBflow_clone/netlist.v}
set rtl_info(target_files) {/Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_SYNTH_genus_test1/work/SYNTH/rtl1/rtl/netlist.v}
set rtl_info(timestamp) "Wed Jun 03 21:07:15 IST 2026"
set rtl_info(file_count) "1"
