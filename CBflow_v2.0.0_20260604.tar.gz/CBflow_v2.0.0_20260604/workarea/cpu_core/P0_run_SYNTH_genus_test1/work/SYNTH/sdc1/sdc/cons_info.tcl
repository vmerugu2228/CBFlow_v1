# Constraints Information
set cons_info(source_file) "/Users/vmerugu/projects/CBflow_clone/func.sdc"
set cons_info(target_file) "/Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_SYNTH_genus_test1/work/SYNTH/sdc1/sdc/func.sdc"
set cons_info(timestamp) "Thu Jun 04 12:25:23 IST 2026"
set cons_info(size) "44"
