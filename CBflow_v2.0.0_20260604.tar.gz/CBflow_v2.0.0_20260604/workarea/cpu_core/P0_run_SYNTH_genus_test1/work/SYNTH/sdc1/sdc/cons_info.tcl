# Constraints Information
set cons_info(source_file) "/Users/vmerugu/projects/CBflow_clone/func.sdc"
set cons_info(target_file) "/Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_SYNTH_genus_test1/work/SYNTH/sdc1/sdc/func.sdc"
set cons_info(timestamp) "Wed Jun 03 21:07:15 IST 2026"
set cons_info(size) "44"
