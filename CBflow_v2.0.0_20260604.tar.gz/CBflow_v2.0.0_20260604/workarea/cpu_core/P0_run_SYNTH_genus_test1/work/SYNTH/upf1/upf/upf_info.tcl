# UPF Information
set upf_info(source_file) "/Users/vmerugu/projects/CBflow_clone/power.upf"
set upf_info(target_file) "/Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_SYNTH_genus_test1/work/SYNTH/upf1/upf/power.upf"
set upf_info(timestamp) "Thu Jun 04 12:25:23 IST 2026"
set upf_info(size) "12"
set upf_info(status) "linked"
