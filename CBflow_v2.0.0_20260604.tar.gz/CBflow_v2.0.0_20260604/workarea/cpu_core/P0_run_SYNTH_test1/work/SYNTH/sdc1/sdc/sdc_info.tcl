set sdc_info(timestamp) "Wed Jun 03 09:41:44 IST 2026"
set sdc_info(status) "loaded"
