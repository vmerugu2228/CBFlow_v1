set sdc_info(timestamp) "Thu Jun 04 12:26:11 IST 2026"
set sdc_info(status) "loaded"
