#!/bin/csh -f
# CBflow tool launch wrapper — export_data
# Generated: Thu Jun 04 12:26:21 IST 2026
fc_shell -f /Users/vmerugu/projects/CBflow_clone/PD/cmds/SYNTH/synopsys/fc/v1.0.0/export_data_fc.tcl -output_log_file /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_SYNTH_test1/work/SYNTH/export_data1/run/export_data1.log
