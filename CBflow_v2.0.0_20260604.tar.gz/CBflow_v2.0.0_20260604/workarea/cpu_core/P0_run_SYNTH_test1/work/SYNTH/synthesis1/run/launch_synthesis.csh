#!/bin/csh -f
# CBflow tool launch wrapper — synthesis
# Generated: Thu Jun 04 12:26:18 IST 2026
fc_shell -f /Users/vmerugu/projects/CBflow_clone/PD/cmds/SYNTH/synopsys/fc/v1.0.0/synthesis_fc.tcl -output_log_file /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_SYNTH_test1/work/SYNTH/synthesis1/run/synthesis1.log
