set rtl_info(timestamp) "Thu Jun 04 12:26:11 IST 2026"
set rtl_info(status) "loaded"
