set rtl_info(timestamp) "Wed Jun 03 09:41:44 IST 2026"
set rtl_info(status) "loaded"
