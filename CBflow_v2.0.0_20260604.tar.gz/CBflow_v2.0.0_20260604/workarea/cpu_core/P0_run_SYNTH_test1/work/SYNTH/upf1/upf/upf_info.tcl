set upf_info(timestamp) "Thu Jun 04 12:26:11 IST 2026"
set upf_info(status) "loaded"
