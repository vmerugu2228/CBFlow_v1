// Gate-level netlist [TEST MODE]
