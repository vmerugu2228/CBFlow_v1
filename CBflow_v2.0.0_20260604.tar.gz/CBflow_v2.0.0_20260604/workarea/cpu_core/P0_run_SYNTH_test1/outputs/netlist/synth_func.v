// Functional netlist (no pg) [TEST MODE]
