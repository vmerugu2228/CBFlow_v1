set spef_info(timestamp) "Wed Jun 03 21:08:26 IST 2026"
set spef_info(status) "loaded"
