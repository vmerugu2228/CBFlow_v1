set spef_info(timestamp) "Thu Jun 04 12:23:27 IST 2026"
set spef_info(status) "loaded"
