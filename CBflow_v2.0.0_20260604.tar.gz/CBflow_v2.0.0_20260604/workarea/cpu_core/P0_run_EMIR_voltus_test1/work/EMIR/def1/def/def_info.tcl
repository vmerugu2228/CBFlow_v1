set def_info(timestamp) "Wed Jun 03 21:08:26 IST 2026"
set def_info(status) "loaded"
