set def_info(timestamp) "Thu Jun 04 12:23:27 IST 2026"
set def_info(status) "loaded"
