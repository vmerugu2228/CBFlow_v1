#!/bin/csh -f
# CBFlow tool launch wrapper — EMIR power_analysis
# Generated: Wed Jun 03 21:08:29 IST 2026
voltus -files /Users/vmerugu/projects/CBflow_clone/PD/cmds/EMIR/cadence/voltus/v1.0.0/power_analysis_voltus.tcl -log /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_EMIR_voltus_test1/work/EMIR/power_analysis1/run/power_analysis1.log
