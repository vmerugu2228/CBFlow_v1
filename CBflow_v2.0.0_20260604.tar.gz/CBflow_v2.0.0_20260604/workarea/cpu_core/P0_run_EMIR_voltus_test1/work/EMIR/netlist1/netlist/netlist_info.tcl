set netlist_info(timestamp) "Wed Jun 03 21:08:26 IST 2026"
set netlist_info(status) "loaded"
