#!/bin/csh -f
# CBFlow tool launch wrapper — EMIR ir_drop
# Generated: Wed Jun 03 21:08:33 IST 2026
voltus -files /Users/vmerugu/projects/CBflow_clone/PD/cmds/EMIR/cadence/voltus/v1.0.0/ir_drop_voltus.tcl -log /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_EMIR_voltus_test1/work/EMIR/ir_drop1/run/ir_drop1.log
