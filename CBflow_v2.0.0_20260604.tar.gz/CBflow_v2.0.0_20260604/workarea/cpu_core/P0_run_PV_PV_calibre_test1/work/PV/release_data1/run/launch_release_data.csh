#!/bin/csh -f
# CBflow tool launch wrapper — release_data
# Generated: Thu Jun 04 12:25:05 IST 2026
calibre /Users/vmerugu/projects/CBflow_clone/PD/cmds/PV/mentor/calibre/v1.0.0/release_data_calibre.tcl |& tee /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_PV_PV_calibre_test1/work/PV/release_data1/run/release_data1.log
