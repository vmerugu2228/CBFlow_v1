#!/bin/csh -f
# CBFlow tool launch wrapper — PV erc
# Generated: Wed Jun 03 21:08:37 IST 2026
calibre /Users/vmerugu/projects/CBflow_clone/PD/cmds/PV/mentor/calibre/v1.0.0/erc_calibre.tcl |& tee /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_PV_PV_calibre_test1/work/PV/erc1/run/erc1.log
