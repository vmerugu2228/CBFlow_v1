#!/bin/csh -f
# CBflow tool launch wrapper — erc
# Generated: Thu Jun 04 12:24:59 IST 2026
calibre /Users/vmerugu/projects/CBflow_clone/PD/cmds/PV/mentor/calibre/v1.0.0/erc_calibre.tcl |& tee /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_PV_PV_calibre_test1/work/PV/erc1/run/erc1.log
