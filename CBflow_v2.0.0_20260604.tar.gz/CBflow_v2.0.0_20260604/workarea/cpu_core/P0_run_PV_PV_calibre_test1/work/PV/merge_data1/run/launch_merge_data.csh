#!/bin/csh -f
# CBFlow tool launch wrapper — PV merge_data
# Generated: Wed Jun 03 21:08:37 IST 2026
calibre /Users/vmerugu/projects/CBflow_clone/PD/cmds/PV/mentor/calibre/v1.0.0/merge_data_calibre.tcl |& tee /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_PV_PV_calibre_test1/work/PV/merge_data1/run/merge_data1.log
