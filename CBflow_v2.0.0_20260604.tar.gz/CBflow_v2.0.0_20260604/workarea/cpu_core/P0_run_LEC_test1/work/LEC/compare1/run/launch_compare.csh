#!/bin/csh -f
# CBflow tool launch wrapper — compare
# Generated: Thu Jun 04 12:23:48 IST 2026
fm_shell -f /Users/vmerugu/projects/CBflow_clone/PD/cmds/LEC/synopsys/formality/v1.0.0/compare_formality.tcl -log /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_LEC_test1/work/LEC/compare1/run/compare1.log
