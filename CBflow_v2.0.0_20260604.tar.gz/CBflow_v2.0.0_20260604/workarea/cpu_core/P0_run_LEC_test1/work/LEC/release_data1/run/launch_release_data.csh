#!/bin/csh -f
# CBflow tool launch wrapper — release_data
# Generated: Thu Jun 04 12:23:51 IST 2026
fm_shell -f /Users/vmerugu/projects/CBflow_clone/PD/cmds/LEC/synopsys/formality/v1.0.0/release_data_formality.tcl -log /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_LEC_test1/work/LEC/release_data1/run/release_data1.log
