set netlist_golden_info(timestamp) "Thu Jun 04 12:23:45 IST 2026"
set netlist_golden_info(status) "loaded"
