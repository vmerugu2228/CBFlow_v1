set netlist_golden_info(timestamp) "Wed Jun 03 09:39:59 IST 2026"
set netlist_golden_info(status) "loaded"
