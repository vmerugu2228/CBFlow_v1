set netlist_info(timestamp) "Wed Jun 03 21:07:58 IST 2026"
set netlist_info(status) "loaded"
