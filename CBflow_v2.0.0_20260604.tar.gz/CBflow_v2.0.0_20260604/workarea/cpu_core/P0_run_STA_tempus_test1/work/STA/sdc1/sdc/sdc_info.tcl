set sdc_info(timestamp) "Thu Jun 04 12:25:06 IST 2026"
set sdc_info(status) "loaded"
