#!/bin/csh -f
# CBFlow tool launch wrapper — STA release_data
# Generated: Wed Jun 03 21:08:12 IST 2026
tempus -files /Users/vmerugu/projects/CBflow_clone/PD/cmds/STA/cadence/tempus/v1.0.0/release_data_tempus.tcl -log /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_STA_tempus_test1/work/STA/release_data1/run/release_data1.log
