#!/bin/csh -f
# CBFlow tool launch wrapper — STA reporting
# Generated: Wed Jun 03 21:08:08 IST 2026
tempus -files /Users/vmerugu/projects/CBflow_clone/PD/cmds/STA/cadence/tempus/v1.0.0/reporting_tempus.tcl -log /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_STA_tempus_test1/work/STA/reporting1/run/reporting1.log
