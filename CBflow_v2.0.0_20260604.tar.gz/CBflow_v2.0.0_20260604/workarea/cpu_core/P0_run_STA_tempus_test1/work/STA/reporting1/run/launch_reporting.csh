#!/bin/csh -f
# CBflow tool launch wrapper — reporting
# Generated: Thu Jun 04 12:25:16 IST 2026
tempus -files /Users/vmerugu/projects/CBflow_clone/PD/cmds/STA/cadence/tempus/v1.0.0/reporting_tempus.tcl -log /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_STA_tempus_test1/work/STA/reporting1/run/reporting1.log
