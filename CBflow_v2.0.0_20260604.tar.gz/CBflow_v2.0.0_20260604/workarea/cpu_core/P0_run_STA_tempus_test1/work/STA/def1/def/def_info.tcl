set def_info(timestamp) "Wed Jun 03 21:07:58 IST 2026"
set def_info(status) "loaded"
