# SDC Information
set sdc_info(source_file) "/Users/vmerugu/projects/CBflow_clone/func.sdc"
set sdc_info(target_file) "/Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_PNR_innovus_test1/work/PNR/sdc1/sdc/func.sdc"
set sdc_info(timestamp) "Wed Jun 03 21:07:28 IST 2026"
set sdc_info(size) "44"
