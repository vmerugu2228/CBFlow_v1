#!/bin/csh -f
# CBflow tool launch wrapper — init_design
# Generated: Thu Jun 04 12:23:55 IST 2026
innovus -files /Users/vmerugu/projects/CBflow_clone/PD/cmds/PNR/cadence/innovus/v1.0.0/init_design_innovus.tcl -log /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_PNR_innovus_test1/work/PNR/init_design1/run/init_design1.log
