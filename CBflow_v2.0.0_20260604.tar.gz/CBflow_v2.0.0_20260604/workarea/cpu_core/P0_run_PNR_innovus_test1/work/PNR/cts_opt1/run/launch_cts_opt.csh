#!/bin/csh -f
# CBFlow tool launch wrapper — PNR cts_opt
# Generated: Wed Jun 03 21:07:41 IST 2026
innovus -files /Users/vmerugu/projects/CBflow_clone/PD/cmds/PNR/cadence/innovus/v1.0.0/cts_opt_innovus.tcl -log /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_PNR_innovus_test1/work/PNR/cts_opt1/run/cts_opt1.log
