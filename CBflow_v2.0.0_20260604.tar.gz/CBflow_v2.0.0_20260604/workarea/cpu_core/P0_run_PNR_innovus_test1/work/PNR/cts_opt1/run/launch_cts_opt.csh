#!/bin/csh -f
# CBflow tool launch wrapper — cts_opt
# Generated: Thu Jun 04 12:24:05 IST 2026
innovus -files /Users/vmerugu/projects/CBflow_clone/PD/cmds/PNR/cadence/innovus/v1.0.0/cts_opt_innovus.tcl -log /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_PNR_innovus_test1/work/PNR/cts_opt1/run/cts_opt1.log
