# DEF Information
set def_info(source_file) "/Users/vmerugu/projects/CBflow_clone/design.def"
set def_info(target_file) "/Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_PNR_innovus_test1/work/PNR/def1/def/design.def"
set def_info(timestamp) "Wed Jun 03 21:07:28 IST 2026"
set def_info(size) "0"
