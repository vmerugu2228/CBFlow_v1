#!/bin/csh -f
# CBFlow tool launch wrapper — PNR pro
# Generated: Wed Jun 03 21:07:48 IST 2026
innovus -files /Users/vmerugu/projects/CBflow_clone/PD/cmds/PNR/cadence/innovus/v1.0.0/post_route_innovus.tcl -log /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_PNR_innovus_test1/work/PNR/pro1/run/pro1.log
