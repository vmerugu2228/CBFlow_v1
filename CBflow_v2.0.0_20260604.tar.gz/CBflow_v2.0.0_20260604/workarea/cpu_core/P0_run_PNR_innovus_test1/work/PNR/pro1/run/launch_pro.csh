#!/bin/csh -f
# CBflow tool launch wrapper — pro
# Generated: Thu Jun 04 12:24:11 IST 2026
innovus -files /Users/vmerugu/projects/CBflow_clone/PD/cmds/PNR/cadence/innovus/v1.0.0/post_route_innovus.tcl -log /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_PNR_innovus_test1/work/PNR/pro1/run/pro1.log
