#!/bin/csh -f
# CBFlow tool launch wrapper — PNR cts
# Generated: Wed Jun 03 21:07:38 IST 2026
innovus -files /Users/vmerugu/projects/CBflow_clone/PD/cmds/PNR/cadence/innovus/v1.0.0/cts_innovus.tcl -log /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_PNR_innovus_test1/work/PNR/cts1/run/cts1.log
