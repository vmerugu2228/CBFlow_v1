#!/bin/csh -f
# CBFlow tool launch wrapper — PNR release_data
# Generated: Wed Jun 03 21:07:58 IST 2026
innovus -files /Users/vmerugu/projects/CBflow_clone/PD/cmds/PNR/cadence/innovus/v1.0.0/release_data_handler.tcl -log /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_PNR_innovus_test1/work/PNR/release_data1/run/release_data1.log
