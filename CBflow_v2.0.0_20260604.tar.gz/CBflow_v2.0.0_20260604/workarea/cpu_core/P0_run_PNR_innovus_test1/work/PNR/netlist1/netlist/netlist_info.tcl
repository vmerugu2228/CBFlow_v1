# Netlist Information
set netlist_info(source_file) "/Users/vmerugu/projects/CBflow_clone/netlist.v"
set netlist_info(target_file) "/Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_PNR_innovus_test1/work/PNR/netlist1/netlist/netlist.v"
set netlist_info(timestamp) "Thu Jun 04 12:23:52 IST 2026"
set netlist_info(size) "0"
