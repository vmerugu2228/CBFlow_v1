#!/bin/csh -f
# CBFlow tool launch wrapper — PNR export_data
# Generated: Wed Jun 03 21:07:54 IST 2026
innovus -files /Users/vmerugu/projects/CBflow_clone/PD/cmds/PNR/cadence/innovus/v1.0.0/export_db_innovus.tcl -log /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_PNR_innovus_test1/work/PNR/export_data1/run/export_data1.log
