#!/bin/csh -f
# CBflow tool launch wrapper — export_data
# Generated: Thu Jun 04 12:24:18 IST 2026
innovus -files /Users/vmerugu/projects/CBflow_clone/PD/cmds/PNR/cadence/innovus/v1.0.0/export_db_innovus.tcl -log /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_PNR_innovus_test1/work/PNR/export_data1/run/export_data1.log
