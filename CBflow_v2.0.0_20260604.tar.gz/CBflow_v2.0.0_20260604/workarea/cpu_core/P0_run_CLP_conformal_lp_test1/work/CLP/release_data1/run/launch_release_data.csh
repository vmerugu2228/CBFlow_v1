#!/bin/csh -f
# CBFlow tool launch wrapper — CLP release_data
# Generated: Wed Jun 03 21:08:26 IST 2026
conformal_lp -dofile /Users/vmerugu/projects/CBflow_clone/PD/cmds/CLP/cadence/conformal_lp/v1.0.0/release_data_conformal_lp.tcl -logfile /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_CLP_conformal_lp_test1/work/CLP/release_data1/run/release_data1.log
