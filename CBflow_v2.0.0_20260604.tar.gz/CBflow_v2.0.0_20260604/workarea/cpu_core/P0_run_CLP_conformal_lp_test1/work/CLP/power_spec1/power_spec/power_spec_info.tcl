set power_spec_info(timestamp) "Wed Jun 03 21:08:19 IST 2026"
set power_spec_info(status) "loaded"
