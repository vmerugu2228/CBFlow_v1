set upf_info(timestamp) "Wed Jun 03 21:08:19 IST 2026"
set upf_info(status) "loaded"
