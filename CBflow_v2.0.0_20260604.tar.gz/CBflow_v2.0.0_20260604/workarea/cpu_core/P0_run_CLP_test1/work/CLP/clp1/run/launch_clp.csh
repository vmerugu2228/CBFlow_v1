#!/bin/csh -f
# CBflow tool launch wrapper — clp
# Generated: Thu Jun 04 12:23:23 IST 2026
vc_lp_shell -f /Users/vmerugu/projects/CBflow_clone/PD/cmds/CLP/synopsys/vc_lp/v1.0.0/clp_vc_lp.tcl -log /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_CLP_test1/work/CLP/clp1/run/clp1.log
