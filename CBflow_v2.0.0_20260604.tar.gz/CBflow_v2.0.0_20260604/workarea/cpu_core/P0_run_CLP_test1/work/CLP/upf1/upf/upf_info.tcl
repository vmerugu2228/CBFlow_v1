set upf_info(timestamp) "Wed Jun 03 09:39:41 IST 2026"
set upf_info(status) "loaded"
