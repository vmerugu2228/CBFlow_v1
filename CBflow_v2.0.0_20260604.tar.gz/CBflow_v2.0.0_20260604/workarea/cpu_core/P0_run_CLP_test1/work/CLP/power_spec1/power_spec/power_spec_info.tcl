set power_spec_info(timestamp) "Thu Jun 04 12:23:20 IST 2026"
set power_spec_info(status) "loaded"
