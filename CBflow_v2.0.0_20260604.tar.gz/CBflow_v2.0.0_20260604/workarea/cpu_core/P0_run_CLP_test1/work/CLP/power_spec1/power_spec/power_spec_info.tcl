set power_spec_info(timestamp) "Wed Jun 03 09:39:41 IST 2026"
set power_spec_info(status) "loaded"
