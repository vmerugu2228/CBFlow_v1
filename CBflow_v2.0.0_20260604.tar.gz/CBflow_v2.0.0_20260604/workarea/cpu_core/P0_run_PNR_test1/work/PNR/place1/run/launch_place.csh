#!/bin/csh -f
# CBFlow tool launch wrapper — PNR place
# Generated: Wed Jun 03 09:40:36 IST 2026
fc_shell -f /Users/vmerugu/projects/CBflow_clone/PD/cmds/PNR/synopsys/fc/v1.0.0/place_fc.tcl -output_log_file /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_PNR_test1/work/PNR/place1/run/place1.log
