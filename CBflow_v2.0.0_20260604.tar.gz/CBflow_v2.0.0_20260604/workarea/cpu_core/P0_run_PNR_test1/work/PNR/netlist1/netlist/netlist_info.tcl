set netlist_info(timestamp) "Wed Jun 03 09:40:36 IST 2026"
set netlist_info(status) "loaded"
