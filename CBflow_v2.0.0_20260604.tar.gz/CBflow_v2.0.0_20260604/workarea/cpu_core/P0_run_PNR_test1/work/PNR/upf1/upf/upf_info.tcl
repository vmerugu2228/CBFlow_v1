set upf_info(timestamp) "Thu Jun 04 12:24:22 IST 2026"
set upf_info(status) "loaded"
