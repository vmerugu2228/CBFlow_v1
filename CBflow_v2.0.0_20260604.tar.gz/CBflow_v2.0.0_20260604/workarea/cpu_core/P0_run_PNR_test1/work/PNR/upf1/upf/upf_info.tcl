set upf_info(timestamp) "Wed Jun 03 09:40:36 IST 2026"
set upf_info(status) "loaded"
