#!/bin/csh -f
# CBFlow tool launch wrapper — PNR signoff
# Generated: Wed Jun 03 09:40:38 IST 2026
fc_shell -f /Users/vmerugu/projects/CBflow_clone/PD/cmds/PNR/synopsys/fc/v1.0.0/signoff_fc.tcl -output_log_file /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_PNR_test1/work/PNR/signoff1/run/signoff1.log
