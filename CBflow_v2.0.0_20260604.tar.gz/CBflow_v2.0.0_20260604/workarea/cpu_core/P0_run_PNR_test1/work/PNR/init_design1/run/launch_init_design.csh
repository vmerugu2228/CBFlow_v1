#!/bin/csh -f
# CBflow tool launch wrapper — init_design
# Generated: Thu Jun 04 12:24:25 IST 2026
fc_shell -f /Users/vmerugu/projects/CBflow_clone/PD/cmds/PNR/synopsys/fc/v1.0.0/init_design_fc.tcl -output_log_file /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_PNR_test1/work/PNR/init_design1/run/init_design1.log
