#!/bin/csh -f
# CBflow tool launch wrapper — route
# Generated: Thu Jun 04 12:24:38 IST 2026
fc_shell -f /Users/vmerugu/projects/CBflow_clone/PD/cmds/PNR/synopsys/fc/v1.0.0/route_fc.tcl -output_log_file /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_PNR_test1/work/PNR/route1/run/route1.log
