#!/bin/csh -f
# CBFlow tool launch wrapper — PNR cts_opt
# Generated: Wed Jun 03 09:40:37 IST 2026
fc_shell -f /Users/vmerugu/projects/CBflow_clone/PD/cmds/PNR/synopsys/fc/v1.0.0/cts_opt_fc.tcl -output_log_file /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_PNR_test1/work/PNR/cts_opt1/run/cts_opt1.log
