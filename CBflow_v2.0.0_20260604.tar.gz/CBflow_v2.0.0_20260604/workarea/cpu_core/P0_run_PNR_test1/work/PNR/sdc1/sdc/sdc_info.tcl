set sdc_info(timestamp) "Thu Jun 04 12:24:22 IST 2026"
set sdc_info(status) "loaded"
