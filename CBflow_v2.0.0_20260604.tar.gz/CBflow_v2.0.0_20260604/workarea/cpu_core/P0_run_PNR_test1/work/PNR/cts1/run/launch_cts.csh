#!/bin/csh -f
# CBflow tool launch wrapper — cts
# Generated: Thu Jun 04 12:24:32 IST 2026
fc_shell -f /Users/vmerugu/projects/CBflow_clone/PD/cmds/PNR/synopsys/fc/v1.0.0/cts_fc.tcl -output_log_file /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_PNR_test1/work/PNR/cts1/run/cts1.log
