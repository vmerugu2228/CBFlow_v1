set spef_info(timestamp) "Thu Jun 04 12:19:50 IST 2026"
set spef_info(status) "loaded"
