#!/bin/csh -f
# CBflow tool launch wrapper — thermal_analysis
# Generated: Thu Jun 04 12:20:00 IST 2026
voltus -files /Users/vmerugu/projects/CBflow_clone/PD/cmds/EMIR/cadence/voltus/v1.0.0/thermal_analysis_voltus.tcl -log /Users/vmerugu/projects/CBflow_clone/workarea/tom/P0_run_EMIR_voltus_test1/work/EMIR/thermal_analysis1/run/thermal_analysis1.log
