#!/bin/csh -f
# CBflow tool launch wrapper — ir_drop
# Generated: Thu Jun 04 12:19:57 IST 2026
voltus -files /Users/vmerugu/projects/CBflow_clone/PD/cmds/EMIR/cadence/voltus/v1.0.0/ir_drop_voltus.tcl -log /Users/vmerugu/projects/CBflow_clone/workarea/tom/P0_run_EMIR_voltus_test1/work/EMIR/ir_drop1/run/ir_drop1.log
