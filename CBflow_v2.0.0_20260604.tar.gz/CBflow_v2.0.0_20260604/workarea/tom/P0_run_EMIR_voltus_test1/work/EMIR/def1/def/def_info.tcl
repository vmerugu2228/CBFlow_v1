set def_info(timestamp) "Thu Jun 04 12:19:50 IST 2026"
set def_info(status) "loaded"
