set def_info(timestamp) "Thu Jun 04 06:56:25 IST 2026"
set def_info(status) "loaded"
