# DEF Information
set def_info(source_file) "/Users/vmerugu/projects/CBflow_clone/denali.def"
set def_info(target_file) "/Users/vmerugu/projects/CBflow_clone/workarea/tom/P0_run_PNR_innovus_test1/work/PNR/def1/def/denali.def"
set def_info(timestamp) "Thu Jun 04 12:20:07 IST 2026"
set def_info(size) "0"
