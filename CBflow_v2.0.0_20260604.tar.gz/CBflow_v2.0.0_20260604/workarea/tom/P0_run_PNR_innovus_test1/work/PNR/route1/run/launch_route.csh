#!/bin/csh -f
# CBFlow tool launch wrapper — PNR route
# Generated: Thu Jun 04 06:56:59 IST 2026
innovus -files /Users/vmerugu/projects/CBflow_clone/PD/cmds/PNR/cadence/innovus/v1.0.0/route_innovus.tcl -log /Users/vmerugu/projects/CBflow_clone/workarea/tom/P0_run_PNR_innovus_test1/work/PNR/route1/run/route1.log
