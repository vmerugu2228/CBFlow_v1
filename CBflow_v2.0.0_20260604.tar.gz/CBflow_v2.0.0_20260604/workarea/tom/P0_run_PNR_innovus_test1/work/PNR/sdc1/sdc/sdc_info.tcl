# SDC Information
set sdc_info(source_file) "/Users/vmerugu/projects/CBflow_clone/denali_func.sdc"
set sdc_info(target_file) "/Users/vmerugu/projects/CBflow_clone/workarea/tom/P0_run_PNR_innovus_test1/work/PNR/sdc1/sdc/denali_func.sdc"
set sdc_info(timestamp) "Thu Jun 04 06:56:42 IST 2026"
set sdc_info(size) "0"
