# Netlist Information
set netlist_info(source_file) "/Users/vmerugu/projects/CBflow_clone/denali_netlist.v"
set netlist_info(target_file) "/Users/vmerugu/projects/CBflow_clone/workarea/tom/P0_run_PNR_innovus_test1/work/PNR/netlist1/netlist/denali_netlist.v"
set netlist_info(timestamp) "Thu Jun 04 06:56:42 IST 2026"
set netlist_info(size) "0"
