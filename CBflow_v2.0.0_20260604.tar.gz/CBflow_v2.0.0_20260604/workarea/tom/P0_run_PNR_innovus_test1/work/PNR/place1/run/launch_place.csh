#!/bin/csh -f
# CBflow tool launch wrapper — place
# Generated: Thu Jun 04 12:20:14 IST 2026
innovus -files /Users/vmerugu/projects/CBflow_clone/PD/cmds/PNR/cadence/innovus/v1.0.0/place_innovus.tcl -log /Users/vmerugu/projects/CBflow_clone/workarea/tom/P0_run_PNR_innovus_test1/work/PNR/place1/run/place1.log
