#!/usr/bin/env tclsh
# CBFlow Native TCL Run-Specific Environment
# Generated: Thu Jun 04 06:55:26  2026

# Run-Specific Information
set ::env(CBFLOW_RUN_DIR) "/Users/vmerugu/projects/CBflow_clone/workarea/tom/P0_run_PNR_innovus_test1"
set ::env(CBFLOW_FLOW_TYPE) "PNR"
set ::env(CBFLOW_DESIGN_NAME) "tom"
set ::env(CBFLOW_RUN_NAME) "innovus_test1"
set ::env(CBFLOW_PROJECT_PHASE) "P0"

# Workspace-Locked Variables (from init_workspace)
set ::env(CBFLOW_PROJECT_NAME) "denali"
set ::env(CBFLOW_BLOCK_NAME) "tom"

# Core Configuration Paths
set ::env(CONFIG_ROOT) "/Users/vmerugu/projects/CBflow_clone/PD/config"
set ::env(SCRIPTS_ROOT) "/Users/vmerugu/projects/CBflow_clone/PD/utils"
set ::env(PROJECT_ROOT) "/Users/vmerugu/projects/CBflow_clone/PD/config/project/denali"
set ::env(FLOW_DIR) "/Users/vmerugu/projects/CBflow_clone/PD"

# Project Configuration
set ::env(PROJECT_NAME) "denali"
set ::env(PROJECT_VERSION) "v1.0.0"

# Technology Configuration
set ::env(TECHNOLOGY_VENDOR) "gf"
set ::env(TECHNOLOGY_NODE) "28nm"
set ::env(TECHNOLOGY_VERSION) "v1.0.0"
set ::env(TECH_NAME) "gf_28nm"
set ::env(TECH_VERSION) "v1.0.0"
set ::env(SETUP_VERSION) "v1.0.0"

# Release Information
set ::env(CBFLOW_RELEASE_VERSION) "v1.0.0"

# Component Versions (from release)
set ::env(FLOW_CONFIG_VERSION) "v1.0.0"
set ::env(GENERATION_VERSION) "v1.0.0"
set ::env(MAKEFILE_COMMANDS_VERSION) "v1.0.0"
set ::env(NODE_MANAGEMENT_VERSION) "v1.0.0"
set ::env(PROJECT_VERSION) "v1.0.0"
set ::env(TECHNOLOGY_VERSION) "v1.0.0"
set ::env(UTILITIES_VERSION) "v1.0.0"
set ::env(VALIDATION_VERSION) "v1.0.0"

# Utilities Path Configuration
set ::env(UTILS_TCL) "/Users/vmerugu/projects/CBflow_clone/PD/utils/utilities/v1.0.0/utils.tcl"

# Run-specific variables from user configuration
# Additional run-specific variables can be added here
