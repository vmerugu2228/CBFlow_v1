#!/bin/csh -f
# CBFlow tool launch wrapper — CLP release_data
# Generated: Thu Jun 04 06:56:25 IST 2026
conformal_lp -dofile /Users/vmerugu/projects/CBflow_clone/PD/cmds/CLP/cadence/conformal_lp/v1.0.0/release_data_conformal_lp.tcl -logfile /Users/vmerugu/projects/CBflow_clone/workarea/tom/P0_run_CLP_conformal_lp_test1/work/CLP/release_data1/run/release_data1.log
