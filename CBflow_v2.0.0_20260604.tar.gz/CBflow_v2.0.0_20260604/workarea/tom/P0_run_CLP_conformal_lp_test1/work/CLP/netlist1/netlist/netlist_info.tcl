set netlist_info(timestamp) "Thu Jun 04 12:19:43 IST 2026"
set netlist_info(status) "loaded"
