set netlist_info(timestamp) "Thu Jun 04 06:56:18 IST 2026"
set netlist_info(status) "loaded"
