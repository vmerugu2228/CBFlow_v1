set upf_info(timestamp) "Thu Jun 04 06:56:18 IST 2026"
set upf_info(status) "loaded"
