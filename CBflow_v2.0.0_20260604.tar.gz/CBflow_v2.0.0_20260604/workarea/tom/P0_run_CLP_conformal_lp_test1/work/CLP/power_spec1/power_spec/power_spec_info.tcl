set power_spec_info(timestamp) "Thu Jun 04 12:19:43 IST 2026"
set power_spec_info(status) "loaded"
