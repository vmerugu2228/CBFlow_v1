set power_spec_info(timestamp) "Thu Jun 04 06:56:18 IST 2026"
set power_spec_info(status) "loaded"
