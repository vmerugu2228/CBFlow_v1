#!/bin/csh -f
# CBFlow tool launch wrapper — CLP clp
# Generated: Thu Jun 04 06:56:21 IST 2026
conformal_lp -dofile /Users/vmerugu/projects/CBflow_clone/PD/cmds/CLP/cadence/conformal_lp/v1.0.0/clp_conformal_lp.tcl -logfile /Users/vmerugu/projects/CBflow_clone/workarea/tom/P0_run_CLP_conformal_lp_test1/work/CLP/clp1/run/clp1.log
