set def_info(timestamp) "Thu Jun 04 06:57:14 IST 2026"
set def_info(status) "loaded"
