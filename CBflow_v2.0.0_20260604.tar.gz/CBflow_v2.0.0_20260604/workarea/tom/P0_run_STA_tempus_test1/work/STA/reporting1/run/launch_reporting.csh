#!/bin/csh -f
# CBFlow tool launch wrapper — STA reporting
# Generated: Thu Jun 04 06:57:24 IST 2026
tempus -files /Users/vmerugu/projects/CBflow_clone/PD/cmds/STA/cadence/tempus/v1.0.0/reporting_tempus.tcl -log /Users/vmerugu/projects/CBflow_clone/workarea/tom/P0_run_STA_tempus_test1/work/STA/reporting1/run/reporting1.log
