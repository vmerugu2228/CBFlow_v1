#!/bin/csh -f
# CBflow tool launch wrapper — release_data
# Generated: Thu Jun 04 12:21:05 IST 2026
tempus -files /Users/vmerugu/projects/CBflow_clone/PD/cmds/STA/cadence/tempus/v1.0.0/release_data_tempus.tcl -log /Users/vmerugu/projects/CBflow_clone/workarea/tom/P0_run_STA_tempus_test1/work/STA/release_data1/run/release_data1.log
