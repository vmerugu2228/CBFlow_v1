#!/bin/csh -f
# CBFlow tool launch wrapper — STA release_data
# Generated: Thu Jun 04 06:57:27 IST 2026
tempus -files /Users/vmerugu/projects/CBflow_clone/PD/cmds/STA/cadence/tempus/v1.0.0/release_data_tempus.tcl -log /Users/vmerugu/projects/CBflow_clone/workarea/tom/P0_run_STA_tempus_test1/work/STA/release_data1/run/release_data1.log
