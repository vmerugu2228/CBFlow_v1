set netlist_info(timestamp) "Thu Jun 04 06:57:14 IST 2026"
set netlist_info(status) "loaded"
