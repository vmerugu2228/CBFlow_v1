set netlist_info(timestamp) "Thu Jun 04 12:20:52 IST 2026"
set netlist_info(status) "loaded"
