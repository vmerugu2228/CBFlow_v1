#!/bin/csh -f
# CBFlow tool launch wrapper — PV xor
# Generated: Thu Jun 04 07:07:46 IST 2026
calibre /Users/vmerugu/projects/CBflow_clone/PD/cmds/PV/mentor/calibre/v1.0.0/xor_calibre.tcl |& tee /Users/vmerugu/projects/CBflow_clone/workarea/tom/P0_run_PV_calibre_test1/work/PV/xor1/run/xor1.log
