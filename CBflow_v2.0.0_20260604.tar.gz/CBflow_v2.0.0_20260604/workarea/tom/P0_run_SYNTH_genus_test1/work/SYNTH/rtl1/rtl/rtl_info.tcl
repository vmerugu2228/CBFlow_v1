# RTL Information
set rtl_info(source_files) {/Users/vmerugu/projects/CBflow_clone/denali_top.sv}
set rtl_info(target_files) {/Users/vmerugu/projects/CBflow_clone/workarea/tom/P0_run_SYNTH_genus_test1/work/SYNTH/rtl1/rtl/denali_top.sv}
set rtl_info(timestamp) "Thu Jun 04 06:57:28 IST 2026"
set rtl_info(file_count) "1"
