#!/bin/csh -f
# CBflow tool launch wrapper — release_data
# Generated: Thu Jun 04 12:21:19 IST 2026
genus -f /Users/vmerugu/projects/CBflow_clone/PD/cmds/SYNTH/cadence/genus/v1.0.0/release_db_genus.tcl -log /Users/vmerugu/projects/CBflow_clone/workarea/tom/P0_run_SYNTH_genus_test1/work/SYNTH/release_data1/run/release_data1.log
