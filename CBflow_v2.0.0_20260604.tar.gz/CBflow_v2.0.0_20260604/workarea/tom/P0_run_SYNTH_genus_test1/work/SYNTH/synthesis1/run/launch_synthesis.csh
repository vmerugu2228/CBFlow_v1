#!/bin/csh -f
# CBflow tool launch wrapper — synthesis
# Generated: Thu Jun 04 12:21:12 IST 2026
genus -f /Users/vmerugu/projects/CBflow_clone/PD/cmds/SYNTH/cadence/genus/v1.0.0/synthesis_genus.tcl -log /Users/vmerugu/projects/CBflow_clone/workarea/tom/P0_run_SYNTH_genus_test1/work/SYNTH/synthesis1/run/synthesis1.log
