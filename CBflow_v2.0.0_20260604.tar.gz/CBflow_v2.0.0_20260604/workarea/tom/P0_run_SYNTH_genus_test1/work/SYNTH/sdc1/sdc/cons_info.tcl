# Constraints Information
set cons_info(source_file) "/Users/vmerugu/projects/CBflow_clone/denali_func.sdc"
set cons_info(target_file) "/Users/vmerugu/projects/CBflow_clone/workarea/tom/P0_run_SYNTH_genus_test1/work/SYNTH/sdc1/sdc/denali_func.sdc"
set cons_info(timestamp) "Thu Jun 04 12:21:05 IST 2026"
set cons_info(size) "0"
