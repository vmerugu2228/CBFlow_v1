# UPF Information
set upf_info(source_file) "/Users/vmerugu/projects/CBflow_clone/denali_power.upf"
set upf_info(target_file) "/Users/vmerugu/projects/CBflow_clone/workarea/tom/P0_run_SYNTH_genus_test1/work/SYNTH/upf1/upf/denali_power.upf"
set upf_info(timestamp) "Thu Jun 04 06:57:28 IST 2026"
set upf_info(size) "0"
set upf_info(status) "linked"
