#!/usr/bin/env tclsh
# ═══════════════════════════════════════════════════════════════════════════════
# CBFlow - STA Extraction Command File
# Description: Parasitic extraction for accurate timing analysis
# Tool: Cadence Tempus
# Usage: Source this file in Tempus or run standalone
# ═══════════════════════════════════════════════════════════════════════════════

set run_dir $::env(CBFLOW_RUN_DIR)
set env_file "$run_dir/.run.cbflow.tcl"

if {[file exists $env_file]} {
    source $env_file
} else {
    puts stderr "ERROR: Environment file (.run.cbflow.tcl) not found at $env_file"
    exit 1
}

if {[info exists ::env(FLOW_DIR)]} {
    set FLOW_DIR $::env(FLOW_DIR)
} else {
    puts stderr "ERROR: FLOW_DIR not found in environment"
    exit 1
}

if {![info exists ::env(UTILITIES_VERSION)] || $::env(UTILITIES_VERSION) eq ""} {
    puts stderr "ERROR: UTILITIES_VERSION not set."
    exit 1
}

set utils_path "$FLOW_DIR/utils/utilities/$::env(UTILITIES_VERSION)/utils.tcl"
if {[file exists $utils_path]} {
    source $utils_path
} else {
    puts stderr "ERROR: Cannot find flow utilities at $utils_path"
    exit 1
}

namespace import ::CBFlow::Utilities::print_header

set config_file "$run_dir/work/STA/extraction/run/config.tcl"
if {[file exists $config_file]} { source $config_file }

# Source tech_config
if {[info exists ::env(TECH_NAME)] && $::env(TECH_NAME) ne "" && [info exists ::env(TECH_VERSION)]} {
    set _tc "$::env(CONFIG_ROOT)/tech/$::env(TECH_NAME)/$::env(TECH_VERSION)/tech_config.tcl"
    if {[file exists $_tc]} { source -e $_tc }
}

# Source user_config for overrides
if {[file exists "$run_dir/setup/user_config.tcl"]} { source -e "$run_dir/setup/user_config.tcl" }

global sta project tech flow

# Source TEMPUS tool config
set _tool_config "[file dirname [info script]]/tempus_config.tcl"
if {[file exists $_tool_config]} { source $_tool_config }
handle_info "Starting STA extraction stage with Cadence Tempus..."

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │                       MMMC CONFIGURATION                                   │
# └─────────────────────────────────────────────────────────────────────────────┘

# Source MMMC multi-corner configuration for extraction
set mmmc_config_file "$::env(CONFIG_ROOT)/flow/$::env(FLOW_CONFIG_VERSION)/mmmc_config.tcl"
if {[file exists $mmmc_config_file]} {
    source $mmmc_config_file
    handle_info "MMMC configuration loaded: $mmmc_config_file"
    global analysis_views
    if {[info exists analysis_views]} {
        handle_info "  MMMC scenarios available: [llength [array names analysis_views]]"
    }
} else {
    handle_warning "MMMC config not found: $mmmc_config_file -- single-corner extraction"
}

# Source active scenarios if available
set scenarios_file "$run_dir/work/STA/mmmc_setup/run/active_scenarios.tcl"
if {[file exists $scenarios_file]} {
    source $scenarios_file
    handle_info "Active scenarios loaded for extraction"
}

if {![namespace exists ::flow]} {
    namespace eval ::flow {
        variable exec_mode "auto"
        variable current_stage ""
        variable start_time [clock seconds]
        variable flow_errors {}
    }
}
set ::flow::exec_mode "auto"

set WORK_DIR "$run_dir/work/STA/extraction"
set REPORTS_DIR "$WORK_DIR/reports"
set OUTPUTS_DIR "$run_dir/outputs"
file mkdir $REPORTS_DIR
file mkdir $OUTPUTS_DIR

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │                       SETUP LIBRARIES                                      │
# └─────────────────────────────────────────────────────────────────────────────┘

flow_proc setup_libraries {
    global sta project tech flow FLOW_DIR
    handle_info "Setting up libraries for extraction..."

    if {[info exists tech(lib,timing)]} {
        puts "Reading Liberty files:"
        set lib_files [expr {[string match "*{*}*" $tech(lib,timing)] ? $tech(lib,timing) : [list $tech(lib,timing)]}]
        foreach lib $lib_files {
            set project_root [file dirname $FLOW_DIR]
            set expanded_lib [subst $lib]
            set lib_path [file join $project_root $expanded_lib]
            if {[file exists $lib_path]} {
                puts "   $lib"
                read_lib $lib_path
            } else {
                handle_warning "Liberty file not found: $lib_path"
            }
        }
    } else {
        handle_warning "tech(lib,timing) not defined"
    }

    # Read LEF files for physical data
    if {[info exists tech(lef,standard_cells)]} {
        puts "Reading LEF files:"
        set project_root [file dirname $FLOW_DIR]
        if {[info exists tech(lef,technology)]} {
            set lef_path [file join $project_root [subst $tech(lef,technology)]]
            if {[file exists $lef_path]} {
                puts "   [file tail $tech(lef,technology)]"
                read_physical -lef $lef_path
            }
        }
        set lef_path [file join $project_root [subst $tech(lef,standard_cells)]]
        if {[file exists $lef_path]} {
            puts "   [file tail $tech(lef,standard_cells)]"
            read_physical -lef $lef_path
        }
    }

    puts " Libraries setup completed"
}

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │                       READ DESIGN                                          │
# └─────────────────────────────────────────────────────────────────────────────┘

flow_proc read_design {
    global sta project tech flow FLOW_DIR
    handle_info "Reading design for extraction..."

    set run_dir $::env(CBFLOW_RUN_DIR)
    set netlist_dir "$run_dir/work/STA/inputs/netlist"
    set netlist_files [glob -nocomplain "$netlist_dir/*.v" "$netlist_dir/*.sv" "$netlist_dir/*.vg"]

    if {[llength $netlist_files] > 0} {
        puts "Found [llength $netlist_files] netlist files"
        foreach netlist $netlist_files {
            puts "   Reading: [file tail $netlist]"
            read_verilog $netlist
        }
    } else {
        handle_error "No netlist files found in $netlist_dir"
    }

    if {[info exists project(top_module)]} {
        puts "Setting top module: $project(top_module)"
        set_top_module $project(top_module)
    }

    puts " Design loaded"
}

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │                       READ CONSTRAINTS                                     │
# └─────────────────────────────────────────────────────────────────────────────┘

flow_proc read_constraints {
    global sta project tech flow
    handle_info "Reading SDC constraints..."

    set run_dir $::env(CBFLOW_RUN_DIR)
    set sdc_files [glob -nocomplain "$run_dir/work/STA/inputs/sdc/*.sdc"]

    if {[llength $sdc_files] > 0} {
        foreach sdc $sdc_files {
            puts "   Reading: [file tail $sdc]"
            read_sdc $sdc
        }
        puts " Constraints loaded"
    } else {
        handle_warning "No SDC files found"
    }
}

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │                       RUN EXTRACTION                                       │
# └─────────────────────────────────────────────────────────────────────────────┘

flow_proc run_extraction {
    global sta project tech flow
    handle_info "Running parasitic extraction..."

    file mkdir "$::OUTPUTS_DIR/extraction"
    file mkdir "$::REPORTS_DIR"

    # Configure extraction settings
    if {[info exists tempus(extraction,mode)]} {
        puts "Extraction mode: $tempus(extraction,mode)"
    } else {
        puts "Extraction mode: default (coupled)"
    }

    if {[info exists tempus(extraction,effort)]} {
        puts "Extraction effort: $tempus(extraction,effort)"
    }

    # Run extraction
    puts "Running parasitic extraction..."
    extract_rc

    # Write SPEF output
    puts "Writing SPEF file..."
    write_spef "$::OUTPUTS_DIR/extraction/parasitic.spef"

    # Generate extraction report
    report_extraction > "$::REPORTS_DIR/extraction_summary.rpt"

    puts " Extraction completed"
}

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │                       VALIDATE EXTRACTION                                  │
# └─────────────────────────────────────────────────────────────────────────────┘

flow_proc validate_extraction_results {
    global sta project tech flow FLOW_DIR
    handle_info "Validating extraction results..."

    set current_dir $::env(CBFLOW_RUN_DIR)

    set spef_file "$current_dir/results/extraction/parasitic.spef"
    if {[file exists $spef_file]} {
        handle_info "SPEF file verified: $spef_file"
    } else {
        handle_warning "SPEF file not found: $spef_file"
    }

    set validation_flow_dir [expr {[info exists FLOW_DIR] ? $FLOW_DIR : $::env(FLOW_DIR)}]
    set enhanced_validation_script "$validation_flow_dir/utils/validation/v1.0.0/enhanced_validate_run.tcl"
    if {[file exists $enhanced_validation_script]} {
        if {[catch {exec tclsh $enhanced_validation_script STA extraction $current_dir $validation_flow_dir} result]} {
            handle_warning "Validation completed with warnings: $result"
        } else {
            handle_info "Validation completed successfully"
        }
    }
}

# ┌─────────────────────────────────────────────────────────────────────────────┐
# │                           EXECUTION CONTROL                                │
# └─────────────────────────────────────────────────────────────────────────────┘

handle_info "═══════════════════════════════════════════════════════════════════════════════"
handle_info " CBFlow STA Extraction with Cadence Tempus"
handle_info "═══════════════════════════════════════════════════════════════════════════════"

flow_proc extraction_flow {
    handle_info "Executing STA extraction flow..."

    flow_exec setup_libraries
    flow_exec read_design
    flow_exec read_constraints
    flow_exec run_extraction
    flow_exec validate_extraction_results

    handle_info "═══════════════════════════════════════════════════════════════════════════════"
    handle_info " STA Extraction Complete!"
    handle_info "═══════════════════════════════════════════════════════════════════════════════"
    puts "SPEF output: results/extraction/parasitic.spef"
    handle_info "STA extraction completed successfully"
}

if {[info exists argv0] && $argv0 eq [info script]} {
    flow_exec extraction_flow
} else {
    puts " CBFlow STA extraction procedures loaded"
    puts "Available: setup_libraries, read_design, read_constraints, run_extraction, validate_extraction_results, extraction_flow"
}

# Exit tool after stage completion
exit
