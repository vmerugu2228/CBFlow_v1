#!/usr/bin/env tclsh
# CBFlow STA timing - Synopsys PrimeTime | Static timing analysis
set run_dir $::env(CBFLOW_RUN_DIR)
set env_file "$run_dir/.run.cbflow.tcl"
if {[file exists $env_file]} { source -e $env_file } else { puts stderr "ERROR: .run.cbflow.tcl not found"; exit 1 }
if {[info exists ::env(FLOW_DIR)]} { set FLOW_DIR $::env(FLOW_DIR) } else { puts stderr "ERROR: FLOW_DIR not set"; exit 1 }
if {![info exists ::env(UTILITIES_VERSION)] || $::env(UTILITIES_VERSION) eq ""} { puts stderr "ERROR: UTILITIES_VERSION not set"; exit 1 }
set utils_path "$FLOW_DIR/utils/utilities/$::env(UTILITIES_VERSION)/utils.tcl"
if {[file exists $utils_path]} { source -e $utils_path } else { puts stderr "ERROR: Utils not found"; exit 1 }
namespace import ::CBFlow::Utilities::print_header
set config_file "$run_dir/work/STA/timing/run/config.tcl"
if {[file exists $config_file]} { source -e $config_file }

# Source tech_config
if {[info exists ::env(TECH_NAME)] && $::env(TECH_NAME) ne "" && [info exists ::env(TECH_VERSION)]} {
    set _tc "$::env(CONFIG_ROOT)/tech/$::env(TECH_NAME)/$::env(TECH_VERSION)/tech_config.tcl"
    if {[file exists $_tc]} { source -e $_tc }
}

# Source user_config for overrides
if {[file exists "$run_dir/setup/user_config.tcl"]} { source -e "$run_dir/setup/user_config.tcl" }

global sta project tech flow
# Source PT tool config
set _tool_config "[file dirname [info script]]/pt_config.tcl"
if {[file exists $_tool_config]} { source $_tool_config }
handle_info "Starting STA timing with Synopsys PrimeTime..."
if {![namespace exists ::flow]} { namespace eval ::flow { variable exec_mode "auto"; variable start_time [clock seconds]; variable flow_errors {} } }
set ::flow::exec_mode "auto"

set WORK_DIR "$run_dir/work/STA/timing"
set REPORTS_DIR "$WORK_DIR/reports"
set OUTPUTS_DIR "$run_dir/outputs"
file mkdir $REPORTS_DIR
file mkdir $OUTPUTS_DIR

# ---------------------------------------------------------------------------
# flow_proc: configure_timing
# Configure timing analysis settings and options
# ---------------------------------------------------------------------------
flow_proc configure_timing {
    handle_info "Configuring timing analysis settings..."
    set run_dir $::env(CBFLOW_RUN_DIR)
    file mkdir "$::OUTPUTS_DIR/timing"
    file mkdir "$::REPORTS_DIR"

    # Set timing analysis mode
    if {[info exists ::sta(ANALYSIS_TYPE)]} {
        set_app_var timing_report_unconstrained_paths true
        handle_info "Analysis type: $::sta(ANALYSIS_TYPE)"
    }

    # Enable POCV/AOCV based on ocv_mode config
    set_app_var timing_pocvm_enable_analysis [expr {$pt(analysis,ocv_mode) eq "pocv"}]
    if {[expr {$pt(analysis,ocv_mode) eq "pocv"}]} {
        handle_info "POCV analysis enabled"
    }
    set_app_var timing_aocvm_enable_analysis [expr {$pt(analysis,ocv_mode) eq "aocv"}]
    if {[expr {$pt(analysis,ocv_mode) eq "aocv"}]} {
        handle_info "AOCV analysis enabled"
    }

    # Set SI analysis options
    set_app_var si_enable_analysis $pt(analysis,si_aware)
    if {$pt(analysis,si_aware)} {
        set_app_var si_xtalk_delay_analysis_mode bottom_up
        handle_info "Signal integrity analysis enabled"
    }

    # Set derating factors
    if {[info exists ::sta(DERATE_EARLY)]} {
        set_timing_derate -early $::sta(DERATE_EARLY)
    }
    if {[info exists ::sta(DERATE_LATE)]} {
        set_timing_derate -late $::sta(DERATE_LATE)
    }

    # Set clock uncertainty
    if {[info exists ::sta(CLOCK_UNCERTAINTY_SETUP)]} {
        set_clock_uncertainty -setup $::sta(CLOCK_UNCERTAINTY_SETUP) [all_clocks]
    }
    if {[info exists ::sta(CLOCK_UNCERTAINTY_HOLD)]} {
        set_clock_uncertainty -hold $::sta(CLOCK_UNCERTAINTY_HOLD) [all_clocks]
    }

    # Set max paths for reporting
    set ::sta_max_paths $pt(analysis,max_paths)

    handle_info "Timing analysis configuration completed"
}

# ---------------------------------------------------------------------------
# flow_proc: run_sta
# Execute full static timing analysis with setup and hold checks
# ---------------------------------------------------------------------------
flow_proc run_sta {
    handle_info "Running static timing analysis..."
    set run_dir $::env(CBFLOW_RUN_DIR)
    set rpt_dir "$::REPORTS_DIR"

    if {![info exists ::sta_max_paths]} { set ::sta_max_paths $pt(analysis,max_paths) }

    # Full timing update
    update_timing -full
    handle_info "Timing updated"

    # Setup (max delay) analysis
    handle_info "Running setup analysis..."
    report_timing -delay max -max_paths $::sta_max_paths -nworst 5 \
        -significant_digits $pt(analysis,significant_digits) \
        > "$rpt_dir/setup_timing.rpt"

    # Hold (min delay) analysis
    handle_info "Running hold analysis..."
    report_timing -delay min -max_paths $::sta_max_paths -nworst 5 \
        -significant_digits $pt(analysis,significant_digits) \
        > "$rpt_dir/hold_timing.rpt"

    # Path group analysis
    report_timing -delay max -max_paths $pt(analysis,max_paths) -group reg2reg \
        > "$rpt_dir/reg2reg_timing.rpt"
    report_timing -delay max -max_paths $pt(analysis,max_paths) -group in2reg \
        > "$rpt_dir/in2reg_timing.rpt"
    report_timing -delay max -max_paths $pt(analysis,max_paths) -group reg2out \
        > "$rpt_dir/reg2out_timing.rpt"

    # Clock domain crossing paths
    report_timing -delay max -max_paths $pt(analysis,max_paths) -path_type full_clock \
        > "$rpt_dir/clock_domain_timing.rpt"

    # Clock latency and skew
    report_clock_timing -type skew > "$rpt_dir/clock_skew.rpt"
    report_clock_timing -type latency > "$rpt_dir/clock_latency.rpt"

    # QoR summary
    report_qor > "$rpt_dir/timing_qor.rpt"

    handle_info "STA analysis completed"
}

# ---------------------------------------------------------------------------
# flow_proc: check_violations
# Check and categorize all timing violations
# ---------------------------------------------------------------------------
flow_proc check_violations {
    handle_info "Checking timing violations..."
    set run_dir $::env(CBFLOW_RUN_DIR)
    set rpt_dir "$::REPORTS_DIR"

    # All constraint violators
    report_constraint -all_violators > "$rpt_dir/violations.rpt"

    # Max transition violations
    report_constraint -max_transition -all_violators \
        > "$rpt_dir/max_transition_violations.rpt"

    # Max capacitance violations
    report_constraint -max_capacitance -all_violators \
        > "$rpt_dir/max_capacitance_violations.rpt"

    # Max fanout violations
    report_constraint -max_fanout -all_violators \
        > "$rpt_dir/max_fanout_violations.rpt"

    # Negative slack paths
    report_timing -delay max -slack_lesser_than 0 -max_paths $pt(analysis,max_paths) \
        > "$rpt_dir/negative_slack_setup.rpt"
    report_timing -delay min -slack_lesser_than 0 -max_paths $pt(analysis,max_paths) \
        > "$rpt_dir/negative_slack_hold.rpt"

    # Noise violations (if SI enabled)
    if {[info exists ::sta(ENABLE_SI)] && $::sta(ENABLE_SI)} {
        report_noise -all_violators > "$rpt_dir/noise_violations.rpt"
        handle_info "SI noise violation report generated"
    }

    # Parse violations for summary
    set viol_file "$rpt_dir/violations.rpt"
    if {[file exists $viol_file]} {
        set fp [open $viol_file r]
        set content [read $fp]
        close $fp
        if {[string match "*VIOLATED*" $content]} {
            handle_warning "Timing violations detected - review $viol_file"
        } else {
            handle_info "No timing violations found"
        }
    }

    handle_info "Violation checking completed"
}

# ---------------------------------------------------------------------------
# flow_proc: generate_report
# Generate consolidated STA summary report
# ---------------------------------------------------------------------------
flow_proc generate_report {
    handle_info "Generating STA summary report..."
    set run_dir $::env(CBFLOW_RUN_DIR)
    set rpt_dir "$::REPORTS_DIR"
    set res_dir "$::OUTPUTS_DIR/timing"

    # Design summary
    report_design > "$rpt_dir/design_summary.rpt"

    # Create results summary
    set fp [open "$res_dir/timing.rpt" w]
    puts $fp "================================================================"
    puts $fp "STA Timing Analysis Summary - PrimeTime"
    puts $fp "Date: [clock format [clock seconds]]"
    puts $fp "================================================================"
    puts $fp ""
    puts $fp "Analysis steps:"
    puts $fp "  1. Timing configuration (OCV, SI, derating)"
    puts $fp "  2. Setup analysis (max delay)"
    puts $fp "  3. Hold analysis (min delay)"
    puts $fp "  4. Violation checking"
    puts $fp ""
    puts $fp "Reports generated:"
    foreach f [glob -nocomplain "$rpt_dir/*.rpt"] {
        puts $fp "  [file tail $f]"
    }
    puts $fp "================================================================"
    close $fp

    # Create violations summary
    set fp2 [open "$res_dir/violations.rpt" w]
    puts $fp2 "Violations Summary - [clock format [clock seconds]]"
    puts $fp2 "================================================================"
    puts $fp2 "See detailed reports in: $rpt_dir/"
    close $fp2

    handle_info "STA summary reports generated"
}

# ---------------------------------------------------------------------------
# flow_exec_all: Execute all timing flow_procs in sequence
# ---------------------------------------------------------------------------
flow_proc timing_flow {
    handle_info "Executing STA timing flow..."
    flow_exec configure_timing
    flow_exec run_sta
    flow_exec check_violations
    flow_exec generate_report
    handle_info "STA timing completed successfully"
}
if {[info exists argv0] && $argv0 eq [info script]} { flow_exec timing_flow } else { puts " STA timing procedures loaded" }
exit
