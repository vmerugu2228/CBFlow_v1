#!/usr/bin/env tclsh
# CBFlow PNR export_data1 - Synopsys Fusion Compiler | PNR export_data1
set run_dir $::env(CBFLOW_RUN_DIR)
set env_file "$run_dir/.run.cbflow.tcl"
if {[file exists $env_file]} { source $env_file } else { puts stderr "ERROR: .run.cbflow.tcl not found"; exit 1 }
if {[info exists ::env(FLOW_DIR)]} { set FLOW_DIR $::env(FLOW_DIR) } else { puts stderr "ERROR: FLOW_DIR not set"; exit 1 }
if {![info exists ::env(UTILITIES_VERSION)] || $::env(UTILITIES_VERSION) eq ""} { puts stderr "ERROR: UTILITIES_VERSION not set"; exit 1 }
set utils_path "$FLOW_DIR/utils/utilities/$::env(UTILITIES_VERSION)/utils.tcl"
if {[file exists $utils_path]} { source $utils_path } else { puts stderr "ERROR: Utils not found"; exit 1 }
namespace import ::CBFlow::Utilities::print_header
set config_file "$run_dir/work/$::env(CBFLOW_FLOW_TYPE)/$::env(CBFLOW_NODE_NAME)/run/config.tcl"
if {[file exists $config_file]} { source $config_file }
global pnr project tech flow
# Source FC tool config
set _tool_config "[file dirname [info script]]/fc_config.tcl"
if {[file exists $_tool_config]} { source $_tool_config }
handle_info "Starting PNR export_data1 with Synopsys Fusion Compiler..."
if {![namespace exists ::flow]} { namespace eval ::flow { variable exec_mode "auto"; variable start_time [clock seconds]; variable flow_errors {} } }
set ::flow::exec_mode "auto"

# -- Directories ---------------------------------------------------------------
set WORK_DIR "$run_dir/work/PNR/export_data1"
set REPORTS_DIR "$WORK_DIR/reports"
set OUTPUTS_DIR "$run_dir/outputs"
file mkdir $REPORTS_DIR
file mkdir $OUTPUTS_DIR

# Source tech_config
if {[info exists ::env(TECH_NAME)] && $::env(TECH_NAME) ne "" &&
    [info exists ::env(TECH_VERSION)] && $::env(TECH_VERSION) ne ""} {
    set _tc "$::env(CONFIG_ROOT)/tech/$::env(TECH_NAME)/$::env(TECH_VERSION)/tech_config.tcl"
    if {[file exists $_tc]} { source -e $_tc }
}

# ==============================================================================
# flow_proc: write_netlist
# Description: Write final Verilog netlists (logic-only, PG, PT, FM, LVS)
# ==============================================================================
flow_proc write_netlist {
    handle_info "Writing final netlists..."
    global pnr

    set run_dir $::env(CBFLOW_RUN_DIR)
    file mkdir "$run_dir/results/pnr/netlist"

    # Apply change_names for verilog compliance
    if {[info exists fc(output,name_rules_options)] && $fc(output,name_rules_options) ne ""} {
        eval define_name_rules verilog $fc(output,name_rules_options)
    }
    change_names -rules verilog -hierarchy
    save_block

    # Write logic-only Verilog (no PG, no physical only cells)
    set netlist_logic "$run_dir/results/pnr/netlist/$fc(common,design_name).v"
    handle_info "Writing logic-only netlist: $netlist_logic"
    write_verilog -compress gzip \
        -exclude {scalar_wire_declarations leaf_module_declarations pg_objects end_cap_cells well_tap_cells filler_cells pad_spacer_cells physical_only_cells cover_cells} \
        -hierarchy all \
        ${netlist_logic}

    # Write PG-aware netlist for LVS
    set netlist_lvs "$run_dir/results/pnr/netlist/$fc(common,design_name).lvs.v"
    handle_info "Writing LVS netlist: $netlist_lvs"
    write_verilog -compress gzip \
        -exclude {scalar_wire_declarations leaf_module_declarations empty_modules} \
        -hierarchy all \
        ${netlist_lvs}

    # Write PT-compatible netlist
    set netlist_pt "$run_dir/results/pnr/netlist/$fc(common,design_name).pt.v"
    handle_info "Writing PT netlist: $netlist_pt"
    write_verilog -compress gzip \
        -exclude {scalar_wire_declarations leaf_module_declarations pg_objects end_cap_cells well_tap_cells filler_cells pad_spacer_cells physical_only_cells cover_cells flip_chip_pad_cells} \
        -hierarchy all \
        ${netlist_pt}

    # Write FM-compatible netlist
    set netlist_fm "$run_dir/results/pnr/netlist/$fc(common,design_name).fm.v"
    handle_info "Writing FM netlist: $netlist_fm"
    write_verilog -compress gzip \
        -exclude {scalar_wire_declarations leaf_module_declarations end_cap_cells well_tap_cells filler_cells pad_spacer_cells physical_only_cells cover_cells supply_statements} \
        -hierarchy all \
        ${netlist_fm}

    handle_info "Netlist export completed"
}

# ==============================================================================
# flow_proc: write_def_output
# Description: Write final DEF file
# ==============================================================================
flow_proc write_def_output {
    handle_info "Writing DEF output..."
    global pnr

    set run_dir $::env(CBFLOW_RUN_DIR)
    file mkdir "$run_dir/results/pnr/def"

    set def_file "$run_dir/results/pnr/def/$fc(common,design_name).def"
    handle_info "Writing DEF: $def_file"

    set write_def_cmd "write_def -compress gzip -version 5.8 -include_tech_via_definitions"
    if {[info exists fc(output,def_convert_sites)] && $fc(output,def_convert_sites) ne ""} {
        lappend write_def_cmd -convert_sites $fc(output,def_convert_sites)
    }
    lappend write_def_cmd $def_file

    handle_info "Running: $write_def_cmd"
    eval $write_def_cmd

    if {[file exists $def_file]} {
        handle_info "DEF written successfully"
    } else {
        handle_warning "DEF file was not created: $def_file"
    }

    handle_info "DEF export completed"
}

# ==============================================================================
# flow_proc: write_gds_output
# Description: Write GDSII/OASIS layout data
# ==============================================================================
flow_proc write_gds_output {
    handle_info "Checking GDS/OASIS output settings..."
    global pnr tech

    set run_dir $::env(CBFLOW_RUN_DIR)
    file mkdir "$run_dir/results/pnr/gds"

    # Write GDS
    if {[info exists fc(output,write_gds)] && $fc(output,write_gds)} {
        set gds_file "$run_dir/results/pnr/gds/$fc(common,design_name).gds"
        handle_info "Writing GDSII: $gds_file"

        set gds_cmd "write_gds -compress -hierarchy all -long_names -keep_data_type"
        if {[info exists tech(gds_layer_map)] && [file exists $tech(gds_layer_map)]} {
            lappend gds_cmd -layer_map $tech(gds_layer_map)
        }
        lappend gds_cmd $gds_file

        handle_info "Running: $gds_cmd"
        eval $gds_cmd

        if {[file exists $gds_file]} {
            handle_info "GDSII written successfully"
        } else {
            handle_warning "GDSII file was not created: $gds_file"
        }
    } else {
        handle_info "GDS output not enabled -- skipping"
    }

    # Write OASIS
    if {[info exists fc(output,write_oasis)] && $fc(output,write_oasis)} {
        set oasis_file "$run_dir/results/pnr/gds/$fc(common,design_name).oasis"
        handle_info "Writing OASIS: $oasis_file"

        set oasis_cmd "write_oasis -compress 6 -hierarchy all -keep_data_type"
        if {[info exists tech(oasis_layer_map)] && [file exists $tech(oasis_layer_map)]} {
            lappend oasis_cmd -layer_map $tech(oasis_layer_map)
        }
        lappend oasis_cmd $oasis_file

        handle_info "Running: $oasis_cmd"
        eval $oasis_cmd

        if {[file exists $oasis_file]} {
            handle_info "OASIS written successfully"
        } else {
            handle_warning "OASIS file was not created: $oasis_file"
        }
    }
}

# ==============================================================================
# flow_proc: write_parasitics_output
# Description: Write SPEF parasitics for signoff timing analysis
# ==============================================================================
flow_proc write_parasitics_output {
    handle_info "Writing parasitics..."
    global pnr

    set run_dir $::env(CBFLOW_RUN_DIR)
    file mkdir "$run_dir/results/pnr/spef"

    # Update timing before writing parasitics
    update_timing

    # Write parasitics (SPEF)
    set spef_output "$run_dir/results/pnr/spef/$fc(common,design_name)"
    handle_info "Writing SPEF parasitics: $spef_output"
    write_parasitics -compress -output $spef_output

    handle_info "Parasitics export completed"
}

# ==============================================================================
# flow_proc: write_sdc_output
# Description: Write SDC constraints and routing constraints
# ==============================================================================
flow_proc write_sdc_output {
    handle_info "Writing SDC and script outputs..."
    global pnr

    set run_dir $::env(CBFLOW_RUN_DIR)
    file mkdir "$run_dir/results/pnr/sdc"

    # Write scripts (mode/corner/scenario scripts for PT)
    write_script -force -compress gzip \
        -output "$run_dir/results/pnr/sdc/${fc(common,design_name)}_wscript"
    write_script -force -compress gzip -format pt \
        -output "$run_dir/results/pnr/sdc/${fc(common,design_name)}_wscript_for_pt"

    # Write routing constraints
    write_routing_constraints \
        "$run_dir/results/pnr/sdc/${fc(common,design_name)}_routing_constraints"

    # Write floorplan
    write_floorplan \
        -format icc2 \
        -def_version 5.8 \
        -force \
        -read_def_options {-add_def_only_objects {all} -skip_pg_net_connections} \
        -exclude {scan_chains fills pg_metal_fills routing_rules} \
        -net_types {power ground} \
        -include_physical_status {fixed locked} \
        -output "$run_dir/results/pnr/sdc/${fc(common,design_name)}_floorplan"

    # Write UPF if power intent exists
    if {[info exists fc(output,write_upf)] && $fc(output,write_upf)} {
        save_upf "$run_dir/results/pnr/sdc/$fc(common,design_name).upf"
        handle_info "UPF written"
    }

    # Write per-scenario SDC
    foreach_in_collection scn [all_scenarios] {
        current_scenario $scn
        set scnN [get_object_name $scn]
        handle_info "Writing SDC for scenario $scnN"
        write_sdc -compress gzip \
            -output "$run_dir/results/pnr/sdc/${fc(common,design_name)}_${scnN}.sdc"
    }

    handle_info "SDC and script export completed"
}

# ==============================================================================
# flow_proc: save_design_block
# Description: Save the final design block
# ==============================================================================
flow_proc save_design_block {
    handle_info "Saving final design block..."
    global pnr

    if {[info exists fc(output,block_labeling)] && $fc(output,block_labeling)} {
        save_block -as $fc(common,design_name)/export_data
        handle_info "Block saved as $fc(common,design_name)/export_data"
    } else {
        save_block
        handle_info "Block saved"
    }
}

# ==============================================================================
# flow_proc: generate_reports
# FC-RM: Final QoR snapshot, report_msg
# ==============================================================================
flow_proc generate_reports {
    handle_info "Generating export_data reports..."

    # FC-RM: Final QoR snapshot before data export
    redirect -file $::REPORTS_DIR/report_qor.rpt { report_qor -nosplit }
    redirect -file $::REPORTS_DIR/report_timing.max.rpt {
        report_timing -max_paths 20 -delay_type max -nosplit
    }
    redirect -file $::REPORTS_DIR/report_timing.min.rpt {
        report_timing -max_paths 20 -delay_type min -nosplit
    }

    # FC-RM: report_msg summary
    redirect -file $::REPORTS_DIR/report_msg_summary.rpt { report_msg -summary }

    handle_info "Export data reports generated in: $::REPORTS_DIR"
}

# ==============================================================================
# Source setup.tcl (flow_proc hooks: prepend, append, replace)
# Must be sourced AFTER flow_proc definitions but BEFORE flow_exec_all
# ==============================================================================
set _setup_file "$run_dir/work/$::env(CBFLOW_FLOW_TYPE)/$::env(CBFLOW_NODE_NAME)/run/setup.tcl"
if {[file exists $_setup_file]} {
    handle_info "Sourcing setup hooks: $_setup_file"
    source -e $_setup_file
}
set _override_file "$run_dir/setup/override_setup.tcl"
if {[file exists $_override_file]} {
    handle_info "Sourcing user override: $_override_file"
    source -e $_override_file
}
set _stage_override "$run_dir/setup/override_setup.export_data.tcl"
if {[file exists $_stage_override]} {
    handle_info "Sourcing stage override: $_stage_override"
    source -e $_stage_override
}

# ==============================================================================
# Execute all flow_procs in sequence
# ==============================================================================
flow_exec_all

# Exit tool after stage completion
exit
