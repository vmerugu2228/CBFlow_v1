set upf_info(timestamp) "Thu May 21 09:51:04 IST 2026"
set upf_info(status) "loaded"
