#!/bin/csh -f
# CBFlow tool launch wrapper — SYNTH init_design
# Generated: Thu May 21 09:51:17 IST 2026
fc_shell -f /Users/vmerugu/projects/CBflow_clone/PD/cmds/SYNTH_PNR/synopsys/fc/v1.0.0/init_design_fc.tcl -output_log_file /Users/vmerugu/projects/CBflow_clone/workarea_test/P0_run_SYNTH_test1/work/SYNTH/init_design1/run/init_design1.log
