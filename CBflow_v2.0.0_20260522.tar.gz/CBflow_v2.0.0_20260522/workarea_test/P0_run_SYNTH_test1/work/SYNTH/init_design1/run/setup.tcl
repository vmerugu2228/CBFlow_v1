#!/usr/bin/env tclsh
# ═══════════════════════════════════════════════════════════════════════════════
# CBFlow - Setup Hooks for SYNTH init_design1 (init_design1_default)
# Generated: Thu May 21 09:51:09 IST 2026
# Description: flow_proc hooks only (NO configuration variables)
# ═══════════════════════════════════════════════════════════════════════════════

# CBFlow setup file - configuration is loaded separately

# Use environment variables from .run.cbflow.env
if {[info exists ::env(FLOW_DIR)]} {
    set FLOW_DIR $::env(FLOW_DIR)
} else {
    set FLOW_DIR "/Users/vmerugu/projects/CBflow_clone/PD"
}
if {[info exists ::env(PROJECT_ROOT)]} {
    set ROOT_DIR $::env(PROJECT_ROOT)
} else {
    set ROOT_DIR "[file dirname $FLOW_DIR]"
}
if {[info exists ::env(RUN_DIR)]} {
    set RUN_DIR $::env(RUN_DIR)
} else {
    set RUN_DIR "/Users/vmerugu/projects/CBflow_clone/workarea_test/P0_run_SYNTH_test1"
}

global synth project tech flow

puts "INFO: Setup hooks for SYNTH init_design1 (init_design1_default)"

# ═══════════════════════════════════════════════════════════════════════════════
# FLOW_PROC HOOK EXECUTION ORDER AND PRECEDENCE
# ═══════════════════════════════════════════════════════════════════════════════
# This file contains flow_proc hooks that execute in hierarchical order:
# 1. Global setup (lowest priority) - applies to ALL nodes in ALL flows
# 2. Flow-specific setup - applies to all nodes in this flow type
# 3. Tool-specific setup - applies to specific EDA tool
# 4. Stage-specific setup - applies to specific flow stage
# 5. Override setup (highest priority) - user customizations
#
# Within each level, hooks execute in order: prepend -> main -> append
# Higher priority levels can override lower levels using flow_proc replace
# ═══════════════════════════════════════════════════════════════════════════════

# ───────────────────────────────────────────────────────────────────────────────
# global_setup: /Users/vmerugu/projects/CBflow_clone/PD/config/setup/common/v1.0.0/setup.tcl
# ───────────────────────────────────────────────────────────────────────────────
# CBflow Global Setup — applies to ALL flows, ALL stages
# Priority: LOWEST

# Global flow_proc hook: add design info header to every stage
flow_proc_prepend start_stage {
    handle_info "═══════════════════════════════════════════"
    handle_info "  CBflow Global Hook: Design=$::env(CBFLOW_DESIGN_NAME)"
    handle_info "  Flow=$::env(CBFLOW_FLOW_TYPE) Release=$::env(CBFLOW_RELEASE_VERSION)"
    handle_info "═══════════════════════════════════════════"
}


# ───────────────────────────────────────────────────────────────────────────────
# global_flow_setup: /Users/vmerugu/projects/CBflow_clone/PD/config/setup/common/v1.0.0/flow_setup.tcl
# ───────────────────────────────────────────────────────────────────────────────
#!/usr/bin/env tclsh
# ═══════════════════════════════════════════════════════════════════════════════
# CBFlow - Global Flow Setup (Applied to ALL flow types)
# Description: Common flow_proc hooks and utilities for all flows
# Priority: Low (can be overridden by flow-specific setup)
# ═══════════════════════════════════════════════════════════════════════════════

handle_info "Loading global flow setup - CBFlow flow_proc hooks for ALL flow types"

# Flow initialization hooks
flow_proc_prepend flow_init {
    handle_info "Flow init prepend: Preparing for flow initialization"

    # Initialize flow namespace if not exists
    if {![namespace exists ::flow]} {
        namespace eval ::flow {
            variable exec_mode "manual"
            variable current_stage ""
            variable start_time [clock seconds]
            variable flow_errors {}
        }
        handle_info "Initialized flow namespace"
    }

    # Set default execution mode
    set ::flow::exec_mode "manual"
    set ::flow::start_time [clock seconds]

    # Create flow-level directories
    set flow_dirs {
        "logs/flow"
        "reports/flow"
        "work"
    }

    foreach dir $flow_dirs {
        if {![file exists $dir]} {
            file mkdir $dir
            handle_info "Created flow directory: $dir"
        }
    }

    handle_info "Flow initialization prepend completed"
}

flow_proc_append flow_init {
    handle_info "Flow init append: Flow initialization complete"

    # Validate flow initialization
    if {[info exists ::flow::exec_mode]} {
        handle_info "Flow execution mode: $::flow::exec_mode"
    }

    # Log flow start
    if {[info exists ::flow::start_time]} {
        set start_time_str [clock format $::flow::start_time]
        handle_info "Flow started at: $start_time_str"
    }

    handle_info "Flow initialization append completed"
}

# Stage transition hooks
flow_proc_prepend stage_transition {
    handle_info "Stage transition prepend: Preparing for stage change"

    # Update current stage tracking
    if {[info exists ::flow::current_stage]} {
        set ::flow::previous_stage $::flow::current_stage
    }

    # Create stage transition log
    set transition_log "logs/flow/stage_transitions.log"
    if {![file exists [file dirname $transition_log]]} {
        file mkdir [file dirname $transition_log]
    }

    set log_file [open $transition_log "a"]
    puts $log_file "[clock format [clock seconds]]: Stage transition initiated"
    close $log_file

    handle_info "Stage transition prepend completed"
}

flow_proc_append stage_transition {
    handle_info "Stage transition append: Stage change complete"

    # Log transition completion
    set transition_log "logs/flow/stage_transitions.log"
    set log_file [open $transition_log "a"]
    puts $log_file "[clock format [clock seconds]]: Stage transition completed"
    close $log_file

    # Validate stage transition
    if {[info exists ::flow::current_stage] && [info exists ::flow::previous_stage]} {
        handle_info "Transitioned from $::flow::previous_stage to $::flow::current_stage"
    }

    handle_info "Stage transition append completed"
}

# Error handling hooks
flow_proc_prepend error_handling {
    handle_info "Error handling prepend: Preparing error management"

    # Initialize error tracking
    if {![info exists ::flow::flow_errors]} {
        set ::flow::flow_errors {}
    }

    # Create error log directory
    if {![file exists "logs/errors"]} {
        file mkdir "logs/errors"
        handle_info "Created error log directory"
    }

    handle_info "Error handling prepend completed"
}

flow_proc_append error_handling {
    handle_info "Error handling append: Error management complete"

    # Report error summary
    if {[info exists ::flow::flow_errors] && [llength $::flow::flow_errors] > 0} {
        handle_info "Flow errors encountered: [llength $::flow::flow_errors]"

        # Write error summary
        set error_log "logs/errors/error_summary.log"
        set log_file [open $error_log "w"]
        puts $log_file "Flow Error Summary - [clock format [clock seconds]]"
        puts $log_file "================================================"
        foreach error $::flow::flow_errors {
            puts $log_file "ERROR: $error"
        }
        close $log_file
        handle_info "Error summary written to: $error_log"
    }

    handle_info "Error handling append completed"
}

# Cleanup hooks
flow_proc_prepend cleanup {
    handle_info "Cleanup prepend: Preparing cleanup operations"

    # Create cleanup log
    set cleanup_log "logs/flow/cleanup.log"
    if {![file exists [file dirname $cleanup_log]]} {
        file mkdir [file dirname $cleanup_log]
    }

    set log_file [open $cleanup_log "a"]
    puts $log_file "[clock format [clock seconds]]: Cleanup initiated"
    close $log_file

    handle_info "Cleanup prepend completed"
}

flow_proc_append cleanup {
    handle_info "Cleanup append: Cleanup operations complete"

    # Final flow statistics
    if {[info exists ::flow::start_time]} {
        set total_time [expr {[clock seconds] - $::flow::start_time}]
        handle_info "Total flow execution time: ${total_time} seconds"
    }

    # Log cleanup completion
    set cleanup_log "logs/flow/cleanup.log"
    set log_file [open $cleanup_log "a"]
    puts $log_file "[clock format [clock seconds]]: Cleanup completed"
    close $log_file

    handle_info "Cleanup append completed"
}

# User-customizable flow hook procedures
proc flow_proc_prepend_flow_init {} {
    # Default implementation - users can override this
    handle_info "User flow init prepend hook (default implementation)"
}

proc flow_proc_append_flow_init {} {
    # Default implementation - users can override this
    handle_info "User flow init append hook (default implementation)"
}

proc flow_proc_prepend_stage_transition {} {
    # Default implementation - users can override this
    handle_info "User stage transition prepend hook (default implementation)"
}

proc flow_proc_append_stage_transition {} {
    # Default implementation - users can override this
    handle_info "User stage transition append hook (default implementation)"
}

# Utility procedures for flow management
proc set_flow_stage {stage_name} {
    if {[namespace exists ::flow]} {
        set ::flow::current_stage $stage_name
        handle_info "Flow stage set to: $stage_name"
    }
}

proc add_flow_error {error_msg} {
    if {[namespace exists ::flow]} {
        lappend ::flow::flow_errors $error_msg
        handle_error "Flow error added: $error_msg"
    }
}

proc get_flow_status {} {
    if {[namespace exists ::flow]} {
        set status_info {}
        if {[info exists ::flow::current_stage]} {
            lappend status_info "stage:$::flow::current_stage"
        }
        if {[info exists ::flow::exec_mode]} {
            lappend status_info "mode:$::flow::exec_mode"
        }
        if {[info exists ::flow::flow_errors]} {
            lappend status_info "errors:[llength $::flow::flow_errors]"
        }
        return [join $status_info " "]
    }
    return "flow_namespace_not_initialized"
}

handle_info "Global flow setup complete - CBFlow flow_proc hooks and utilities loaded"

# ───────────────────────────────────────────────────────────────────────────────
# flow_type_setup: /Users/vmerugu/projects/CBflow_clone/PD/config/setup/common/v1.0.0/SYNTH/synopsys/fc/global_setup.tcl
# ───────────────────────────────────────────────────────────────────────────────
#!/usr/bin/env tclsh
# CBFlow - Tool Global Setup Hooks (SYNTH/synopsys/fc)
handle_info "Loading Synopsys FC tool global setup hooks"
flow_proc_prepend flow_init {
    handle_info "FC flow init: Tool-specific initialization"
    foreach dir {"logs/fc" "work/fc" "reports/synth" "results/synth"} {
        if {![file exists $dir]} { file mkdir $dir }
    }
}
flow_proc_append flow_init { handle_info "FC flow init: Tool validation complete" }
handle_info "Synopsys FC tool global setup hooks loaded"


# stage_setup: /Users/vmerugu/projects/CBflow_clone/PD/config/setup/common/v1.0.0/SYNTH/synopsys/fc/init_design_setup.tcl (NOT FOUND - SKIPPED)

# ───────────────────────────────────────────────────────────────────────────────
# project_setup: /Users/vmerugu/projects/CBflow_clone/PD/config/setup/ravendrive/v1.0.0/setup.tcl
# ───────────────────────────────────────────────────────────────────────────────
# Ravendrive Project Setup — applies to all flows in this project
# Priority: Level 4

flow_proc_prepend start_stage {
    handle_info "Ravendrive project: Target frequency = 500MHz"
}


# ───────────────────────────────────────────────────────────────────────────────
# project_flow_setup: /Users/vmerugu/projects/CBflow_clone/PD/config/setup/ravendrive/v1.0.0/SYNTH/flow_setup.tcl
# ───────────────────────────────────────────────────────────────────────────────
#!/usr/bin/env tclsh
# ═══════════════════════════════════════════════════════════════════════════════
# CBFlow - SYNTH Flow Level Setup Hooks
# Description: SYNTH-specific flow_proc hooks that apply to ALL SYNTH flows
# Priority: Medium-High (overrides project, can be overridden by tool-specific setup)
# ═══════════════════════════════════════════════════════════════════════════════

handle_info "Loading SYNTH flow-level setup hooks"

# SYNTH flow initialization hooks
flow_proc_prepend flow_init {
    handle_info "SYNTH flow init prepend: Synthesis flow initialization"

    # Set SYNTH-specific environment
    if {![info exists ::env(SYNTH_FLOW_MODE)]} {
        set ::env(SYNTH_FLOW_MODE) "standard"
    }

    # Create SYNTH-specific directories
    set synth_dirs {
        "logs/synthesis"
        "reports/synthesis"
        "work/SYNTH"
        "results/synthesis"
    }

    foreach dir $synth_dirs {
        if {![file exists $dir]} {
            file mkdir $dir
            handle_info "Created SYNTH directory: $dir"
        }
    }
}

flow_proc_append flow_init {
    handle_info "SYNTH flow init append: Synthesis flow validation complete"

    # Validate SYNTH-specific configuration
    if {[info exists synth(stages)]} {
        handle_info "SYNTH flow stages: [join $synth(stages) {, }]"
    }
}

# SYNTH-specific library setup hooks
flow_proc_prepend setup_libraries {
    handle_info "SYNTH setup libraries prepend: Synthesis library validation"

    # Validate synthesis-specific library requirements
    if {[info exists tech(lib,timing)]} {
        handle_info "Synthesis timing libraries: configured"
    } else {
        add_flow_error "Missing synthesis timing libraries"
    }

    # Set synthesis-specific library variables
    if {[info exists tech(lib,timing)] && [info exists synth(library,effort)]} {
        handle_info "Synthesis library effort: $synth(library,effort)"
    }
}

flow_proc_append setup_libraries {
    handle_info "SYNTH setup libraries append: Synthesis library setup validation"

    # Validate library loading for synthesis
    if {[info exists tech(lib,timing)]} {
        # Check if libraries are accessible
        set lib_files [expr {[string match "*{*}*" $tech(lib,timing)] ? $tech(lib,timing) : [list $tech(lib,timing)]}]
        set valid_libs 0
        foreach lib $lib_files {
            if {[file exists [file join $ROOT_DIR $lib]]} {
                incr valid_libs
            }
        }
        handle_info "SYNTH library validation: $valid_libs/[llength $lib_files] libraries accessible"
    }
}

# SYNTH-specific RTL processing hooks
flow_proc_prepend read_rtl_files {
    handle_info "SYNTH read RTL prepend: Synthesis RTL validation"

    # Validate RTL input configuration
    set rtl_methods 0
    if {[info exists synth(input,rtl_release_tag)]} { incr rtl_methods }
    if {[info exists synth(input,rtl_release_dir)]} { incr rtl_methods }
    if {[info exists synth(input,rtl_filelist)]} { incr rtl_methods }

    if {$rtl_methods == 0} {
        add_flow_error "No RTL input method configured for synthesis"
    } elseif {$rtl_methods > 1} {
        handle_warning "Multiple RTL input methods configured - using priority order"
    }
}

flow_proc_append read_rtl_files {
    handle_info "SYNTH read RTL append: Synthesis RTL processing validation"

    # Validate RTL files were processed
    if {[file exists "work/SYNTH/inputs/rtl"]} {
        set rtl_count [llength [glob -nocomplain "work/SYNTH/inputs/rtl/*"]]
        if {$rtl_count > 0} {
            handle_info "SYNTH RTL validation: $rtl_count files processed"
        } else {
            add_flow_error "No RTL files found after processing"
        }
    }
}

# SYNTH-specific constraint processing hooks
flow_proc_prepend read_constraints {
    handle_info "SYNTH read constraints prepend: Synthesis constraint validation"

    # Validate constraint input configuration
    set sdc_methods 0
    if {[info exists synth(input,sdc_release_tag)]} { incr sdc_methods }
    if {[info exists synth(input,sdc_release_dir)]} { incr sdc_methods }
    if {[info exists synth(input,sdc_func_file)]} { incr sdc_methods }

    if {$sdc_methods == 0} {
        handle_warning "No SDC input method configured - synthesis may not meet timing"
    }
}

flow_proc_append read_constraints {
    handle_info "SYNTH read constraints append: Synthesis constraint validation"

    # Validate constraints were loaded
    if {[file exists "work/SYNTH/inputs/constraints"]} {
        set sdc_count [llength [glob -nocomplain "work/SYNTH/inputs/constraints/*.sdc"]]
        handle_info "SYNTH constraint validation: $sdc_count SDC files loaded"
    }
}

# SYNTH-specific synthesis hooks
flow_proc_prepend synthesize_design {
    handle_info "SYNTH synthesize design prepend: Pre-synthesis validation"

    # Validate synthesis prerequisites
    set prerequisites_ok true

    # Check if libraries are loaded
    if {![info exists tech(lib,timing)]} {
        add_flow_error "Libraries not configured for synthesis"
        set prerequisites_ok false
    }

    # Check if RTL is loaded
    if {![file exists "work/SYNTH/inputs/rtl"] || [llength [glob -nocomplain "work/SYNTH/inputs/rtl/*"]] == 0} {
        add_flow_error "RTL files not available for synthesis"
        set prerequisites_ok false
    }

    if {$prerequisites_ok} {
        handle_info "SYNTH synthesis prerequisites validated"
    }
}

flow_proc_append synthesize_design {
    handle_info "SYNTH synthesize design append: Post-synthesis validation"

    # Validate synthesis outputs
    if {[file exists "results/netlist"]} {
        set netlist_files [glob -nocomplain "results/netlist/*.v"]
        if {[llength $netlist_files] > 0} {
            handle_info "SYNTH synthesis validation: Netlist generated successfully"
        } else {
            add_flow_error "SYNTH synthesis failed - no netlist generated"
        }
    }
}

# SYNTH-specific reporting hooks
flow_proc_append generate_reports {
    handle_info "SYNTH generate reports append: Synthesis-specific reporting"

    # Generate SYNTH flow summary
    set synth_summary "reports/synthesis/synth_flow_summary.rpt"
    if {[file exists "reports/synthesis"]} {
        set fp [open $synth_summary w]
        puts $fp "═══════════════════════════════════════════════════════════════════════════════"
        puts $fp "SYNTH Flow Summary Report"
        puts $fp "═══════════════════════════════════════════════════════════════════════════════"
        puts $fp "Generated: [clock format [clock seconds]]"

        # Report flow status
        if {[info exists ::flow::flow_errors] && [llength $::flow::flow_errors] > 0} {
            puts $fp "Flow Status: FAILED ([llength $::flow::flow_errors] errors)"
            puts $fp "Errors:"
            foreach error $::flow::flow_errors {
                puts $fp "  - $error"
            }
        } else {
            puts $fp "Flow Status: SUCCESS"
        }

        # Report key metrics
        if {[file exists "reports/synthesis/synth_qor.rpt"]} {
            puts $fp "QoR Report: Available"
        }
        if {[file exists "results/netlist/synth.v"]} {
            puts $fp "Netlist: Generated"
        }
        close $fp

        handle_info "SYNTH flow summary generated: $synth_summary"
    }
}

handle_info "SYNTH flow-level setup hooks loaded"

# workspace_setup: /Users/vmerugu/projects/CBflow_clone/workarea_test/P0_run_SYNTH_test1/setup/setup.tcl (NOT FOUND - SKIPPED)

# workspace_flow_setup: /Users/vmerugu/projects/CBflow_clone/workarea_test/P0_run_SYNTH_test1/setup/flow_setup.tcl (NOT FOUND - SKIPPED)

# workspace_stage_setup: /Users/vmerugu/projects/CBflow_clone/workarea_test/P0_run_SYNTH_test1/setup/init_design_setup.tcl (NOT FOUND - SKIPPED)

# Load tool-specific command file with all flow_proc hooks applied
set tool_name "fc"
# Construct proper tool command file path with vendor and version
set tool_cmd_path "$FLOW_DIR/cmds/SYNTH/cadence/${tool_name}/${TOOL_VERSION}/init_design1_${tool_name}.tcl"
if {[file exists $tool_cmd_path]} {
    puts "INFO: Loading tool-specific command file: $tool_cmd_path"
    source $tool_cmd_path
} else {
    puts "ERROR: Command file not found: $tool_cmd_path"
}

