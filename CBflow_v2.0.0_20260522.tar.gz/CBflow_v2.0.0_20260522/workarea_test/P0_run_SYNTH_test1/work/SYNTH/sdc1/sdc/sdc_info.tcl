set sdc_info(timestamp) "Thu May 21 09:51:04 IST 2026"
set sdc_info(status) "loaded"
