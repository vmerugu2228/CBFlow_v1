set netlist_golden_info(timestamp) "Thu May 21 09:57:08 IST 2026"
set netlist_golden_info(status) "loaded"
