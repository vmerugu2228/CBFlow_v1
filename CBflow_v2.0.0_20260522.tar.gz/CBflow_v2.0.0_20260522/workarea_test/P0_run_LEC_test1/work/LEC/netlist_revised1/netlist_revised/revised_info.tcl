set netlist_revised_info(timestamp) "Thu May 21 09:57:08 IST 2026"
set netlist_revised_info(status) "loaded"
