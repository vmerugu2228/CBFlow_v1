#!/bin/csh -f
# CBFlow tool launch wrapper — LEC compare
# Generated: Thu May 21 09:57:21 IST 2026
fm_shell -f /Users/vmerugu/projects/CBflow_clone/PD/cmds/LEC/synopsys/formality/v1.0.0/compare_formality.tcl -output_log_file /Users/vmerugu/projects/CBflow_clone/workarea_test/P0_run_LEC_test1/work/LEC/compare1/run/compare1.log
