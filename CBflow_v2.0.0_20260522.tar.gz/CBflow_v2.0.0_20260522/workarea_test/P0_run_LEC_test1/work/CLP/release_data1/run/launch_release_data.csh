#!/bin/csh -f
# CBFlow tool launch wrapper — CLP release_data
# Generated: Thu May 21 09:57:45 IST 2026
vc_lp_shell -f /Users/vmerugu/projects/CBflow_clone/PD/cmds/CLP/synopsys/vc_lp/v1.0.0/release_data_vc_lp.tcl -output_log_file /Users/vmerugu/projects/CBflow_clone/workarea_test/P0_run_LEC_test1/work/CLP/release_data1/run/release_data1.log
