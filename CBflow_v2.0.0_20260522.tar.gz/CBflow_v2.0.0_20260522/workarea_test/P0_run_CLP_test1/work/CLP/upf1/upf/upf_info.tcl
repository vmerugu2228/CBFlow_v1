set upf_info(timestamp) "Thu May 21 09:58:00 IST 2026"
set upf_info(status) "loaded"
