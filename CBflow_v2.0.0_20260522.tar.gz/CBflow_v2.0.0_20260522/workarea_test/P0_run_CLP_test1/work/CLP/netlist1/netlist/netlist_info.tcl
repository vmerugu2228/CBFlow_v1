set netlist_info(timestamp) "Thu May 21 09:58:00 IST 2026"
set netlist_info(status) "loaded"
