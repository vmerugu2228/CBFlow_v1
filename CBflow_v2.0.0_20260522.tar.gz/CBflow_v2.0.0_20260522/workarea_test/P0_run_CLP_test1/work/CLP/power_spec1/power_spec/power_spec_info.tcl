set power_spec_info(timestamp) "Thu May 21 09:58:00 IST 2026"
set power_spec_info(status) "loaded"
