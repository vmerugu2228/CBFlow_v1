#!/bin/csh -f
# CBFlow tool launch wrapper — CLP clp
# Generated: Thu May 21 09:58:14 IST 2026
vc_lp_shell -f /Users/vmerugu/projects/CBflow_clone/PD/cmds/CLP/synopsys/vc_lp/v1.0.0/clp_vc_lp.tcl -output_log_file /Users/vmerugu/projects/CBflow_clone/workarea_test/P0_run_CLP_test1/work/CLP/clp1/run/clp1.log
