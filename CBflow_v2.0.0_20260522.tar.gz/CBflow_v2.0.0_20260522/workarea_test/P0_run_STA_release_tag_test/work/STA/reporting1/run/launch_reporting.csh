#!/bin/csh -f
# CBFlow tool launch wrapper — STA reporting
# Generated: Thu May 21 22:30:43 IST 2026
pt_shell -f /Users/vmerugu/projects/CBflow_clone/PD/cmds/STA/synopsys/pt/v1.0.0/reporting_pt.tcl -output_log_file /Users/vmerugu/projects/CBflow_clone/workarea_test/P0_run_STA_release_tag_test/work/STA/reporting1/run/reporting1.log
