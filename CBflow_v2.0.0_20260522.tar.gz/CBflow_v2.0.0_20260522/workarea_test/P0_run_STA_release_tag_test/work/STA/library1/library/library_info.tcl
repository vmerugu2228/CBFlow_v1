set library_info(timestamp) "Thu May 21 22:30:43 IST 2026"
set library_info(status) "loaded"
