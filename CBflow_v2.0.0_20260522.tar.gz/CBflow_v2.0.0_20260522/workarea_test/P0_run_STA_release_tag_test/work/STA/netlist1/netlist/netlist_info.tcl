set netlist_info(timestamp) "Thu May 21 22:30:43 IST 2026"
set netlist_info(status) "loaded"
