set def_info(timestamp) "Thu May 21 22:30:23 IST 2026"
set def_info(status) "loaded"
