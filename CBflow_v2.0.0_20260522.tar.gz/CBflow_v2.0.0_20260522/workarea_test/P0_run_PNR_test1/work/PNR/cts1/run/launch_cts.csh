#!/bin/csh -f
# CBFlow tool launch wrapper — PNR cts
# Generated: Thu May 21 09:53:24 IST 2026
fc_shell -f /Users/vmerugu/projects/CBflow_clone/PD/cmds/PNR/synopsys/fc/v1.0.0/cts_fc.tcl -output_log_file /Users/vmerugu/projects/CBflow_clone/workarea_test/P0_run_PNR_test1/work/PNR/cts1/run/cts1.log
