set sdc_info(timestamp) "Thu May 21 09:52:33 IST 2026"
set sdc_info(status) "loaded"
