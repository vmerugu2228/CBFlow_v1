#!/bin/csh -f
# CBFlow tool launch wrapper — PNR release_data
# Generated: Thu May 21 09:55:26 IST 2026
fc_shell -f /Users/vmerugu/projects/CBflow_clone/PD/cmds/PNR/synopsys/fc/v1.0.0/release_data_fc.tcl -output_log_file /Users/vmerugu/projects/CBflow_clone/workarea_test/P0_run_PNR_test1/work/PNR/release_data1/run/release_data1.log
