# Output Manifest — PNR export_data1
# Generated: Thu May 21 09:55:11 IST 2026
# Design: cpu_core

set manifest(netlist,logic) "/Users/vmerugu/projects/CBflow_clone/workarea_test/P0_run_PNR_test1/results/pnr/netlist/cpu_core.v"
set manifest(netlist,pt) "/Users/vmerugu/projects/CBflow_clone/workarea_test/P0_run_PNR_test1/results/pnr/netlist/cpu_core.pt.v"
set manifest(netlist,fm) "/Users/vmerugu/projects/CBflow_clone/workarea_test/P0_run_PNR_test1/results/pnr/netlist/cpu_core.fm.v"
set manifest(netlist,lvs) "/Users/vmerugu/projects/CBflow_clone/workarea_test/P0_run_PNR_test1/results/pnr/netlist/cpu_core.lvs.v"
set manifest(gds) "/Users/vmerugu/projects/CBflow_clone/workarea_test/P0_run_PNR_test1/results/pnr/gds/cpu_core.gds"
set manifest(def) "/Users/vmerugu/projects/CBflow_clone/workarea_test/P0_run_PNR_test1/results/pnr/def/cpu_core.def"
set manifest(sdc) "/Users/vmerugu/projects/CBflow_clone/workarea_test/P0_run_PNR_test1/results/pnr/sdc/cpu_core_func_tt_0p80v_rctyp_25c.sdc"
set manifest(upf) "/Users/vmerugu/projects/CBflow_clone/workarea_test/P0_run_PNR_test1/results/pnr/sdc/cpu_core.upf"
set manifest(spef) "/Users/vmerugu/projects/CBflow_clone/workarea_test/P0_run_PNR_test1/results/pnr/spef/cpu_core.spef"
set manifest(wscript) "/Users/vmerugu/projects/CBflow_clone/workarea_test/P0_run_PNR_test1/results/pnr/sdc/cpu_core_wscript"
set manifest(wscript_for_pt) "/Users/vmerugu/projects/CBflow_clone/workarea_test/P0_run_PNR_test1/results/pnr/sdc/cpu_core_wscript_for_pt"
set manifest(routing_constraints) "/Users/vmerugu/projects/CBflow_clone/workarea_test/P0_run_PNR_test1/results/pnr/sdc/cpu_core_routing_constraints"
set manifest(floorplan) "/Users/vmerugu/projects/CBflow_clone/workarea_test/P0_run_PNR_test1/results/pnr/sdc/cpu_core_floorplan"

set manifest(flow) "PNR"
set manifest(node) "export_data1"
set manifest(design) "cpu_core"
set manifest(run_dir) "/Users/vmerugu/projects/CBflow_clone/workarea_test/P0_run_PNR_test1"
set manifest(timestamp) "Thu May 21 09:55:11 IST 2026"
set manifest(file_count) 13
