set def_info(timestamp) "Thu May 21 09:52:33 IST 2026"
set def_info(status) "loaded"
