#!/bin/csh -f
# CBFlow tool launch wrapper — PNR pro
# Generated: Thu May 21 09:54:25 IST 2026
fc_shell -f /Users/vmerugu/projects/CBflow_clone/PD/cmds/PNR/synopsys/fc/v1.0.0/pro_fc.tcl -output_log_file /Users/vmerugu/projects/CBflow_clone/workarea_test/P0_run_PNR_test1/work/PNR/pro1/run/pro1.log
