#!/bin/csh -f
# CBFlow tool launch wrapper — PNR signoff
# Generated: Thu May 21 09:54:45 IST 2026
fc_shell -f /Users/vmerugu/projects/CBflow_clone/PD/cmds/PNR/synopsys/fc/v1.0.0/signoff_fc.tcl -output_log_file /Users/vmerugu/projects/CBflow_clone/workarea_test/P0_run_PNR_test1/work/PNR/signoff1/run/signoff1.log
