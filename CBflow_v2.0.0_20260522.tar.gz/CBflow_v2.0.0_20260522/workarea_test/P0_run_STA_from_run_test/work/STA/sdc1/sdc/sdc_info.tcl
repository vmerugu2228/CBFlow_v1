set sdc_info(timestamp) "Thu May 21 22:30:33 IST 2026"
set sdc_info(mode_count) 0
