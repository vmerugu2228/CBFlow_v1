#!/bin/csh -f
# CBFlow tool launch wrapper — STA release_data
# Generated: Thu May 21 22:30:34 IST 2026
pt_shell -f /Users/vmerugu/projects/CBflow_clone/PD/cmds/STA/synopsys/pt/v1.0.0/release_data_pt.tcl -output_log_file /Users/vmerugu/projects/CBflow_clone/workarea_test/P0_run_STA_from_run_test/work/STA/release_data1/run/release_data1.log
