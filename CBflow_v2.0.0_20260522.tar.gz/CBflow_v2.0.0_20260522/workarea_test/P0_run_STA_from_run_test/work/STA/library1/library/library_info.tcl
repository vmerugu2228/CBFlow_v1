set library_info(timestamp) "Thu May 21 22:30:33 IST 2026"
set library_info(status) "loaded"
