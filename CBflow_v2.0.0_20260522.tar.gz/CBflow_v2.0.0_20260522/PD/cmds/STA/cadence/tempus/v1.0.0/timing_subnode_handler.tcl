#!/usr/bin/env tclsh
# ═══════════════════════════════════════════════════════════════════════════════
# CBFlow STA TIMING Subnode Handler
# Description: Handles timing stage subnodes (setup, run, validate, finish)
# Supports test_mode: bypasses EDA tool and shows command file instead
# ═══════════════════════════════════════════════════════════════════════════════

# Parse arguments
if {$argc < 1} {
    puts "ERROR: Missing subnode argument"
    puts "Usage: $argv0 <subnode_name> \[run_dir\]"
    exit 1
}

set subnode_name [lindex $argv 0]
set run_dir [expr {$argc > 1 ? [lindex $argv 1] : [pwd]}]
set node_name [expr {$argc > 2 ? [lindex $argv 2] : ""}]

# Load environment
if {[file exists "$run_dir/.run.cbflow.tcl"]} {
    source "$run_dir/.run.cbflow.tcl"
} else {
    puts "ERROR: Cannot find .run.cbflow.tcl in $run_dir"
    exit 1
}

# Load error handling
source "$::env(SCRIPTS_ROOT)/utilities/$::env(UTILITIES_VERSION)/error_utils.tcl"

# Load flow and STA configuration
set flow_config "$::env(CONFIG_ROOT)/flow/$::env(FLOW_CONFIG_VERSION)/flow_config.tcl"
if {[file exists $flow_config]} { source $flow_config }

set sta_config "$::env(CONFIG_ROOT)/flow/$::env(FLOW_CONFIG_VERSION)/node_configs/STA_config.tcl"
if {[file exists $sta_config]} { source $sta_config }

# Source tech_config
if {[info exists ::env(TECH_NAME)] && $::env(TECH_NAME) ne "" && [info exists ::env(TECH_VERSION)]} {
    set _tc "$::env(CONFIG_ROOT)/tech/$::env(TECH_NAME)/$::env(TECH_VERSION)/tech_config.tcl"
    if {[file exists $_tc]} { source -e $_tc }
}
# Source user_config for overrides
if {[file exists "$run_dir/setup/user_config.tcl"]} { source -e "$run_dir/setup/user_config.tcl" }

# Source tool launch config (module load, tool shell, bsub, xterm)
set _launch_config "$::env(CONFIG_ROOT)/flow/$::env(FLOW_CONFIG_VERSION)/tool_launch_config.tcl"
if {[file exists $_launch_config]} { source $_launch_config }

set ::flow_type "STA"
set stage_name "timing"
if {$node_name eq ""} { set node_name $stage_name }
set _tool_ver [expr {[info exists ::env(TEMPUS_VERSION)] ? $::env(TEMPUS_VERSION) : "v1.0.0"}]
set cmd_file "$::env(FLOW_DIR)/cmds/STA/cadence/tempus/$_tool_ver/timing_tempus.tcl"

# Check test mode
set test_mode false
if {[info exists flow(test_mode)] && $flow(test_mode) eq "true"} {
    set test_mode true
}

switch $subnode_name {
    "setup" {
        puts "INFO: $stage_name setup..."
        file mkdir "$run_dir/work/$::flow_type/$node_name/run"
        file mkdir "$run_dir/work/$::flow_type/$node_name/setup"
        puts "INFO: $stage_name setup completed"
    }
    "run" {
        puts "INFO: $stage_name run..."
        if {$test_mode} {
            puts "INFO: \[TEST MODE\] Bypassing EDA tool invocation"
            puts "INFO: Command file: $cmd_file"
            if {[file exists $cmd_file]} {
                puts "INFO: ╔══════════════════════════════════════════════════╗"
                puts "INFO: ║  Command File: [file tail $cmd_file]"
                puts "INFO: ╚══════════════════════════════════════════════════╝"
                set _f [open $cmd_file r]; set _lines [split [read $_f] "\n"]; close $_f
                set _lc 0
                foreach _line $_lines { incr _lc; if {$_lc <= 20} { puts "INFO:   $_line" } }
                if {$_lc > 20} { puts "INFO:   ... ([expr {$_lc - 20}] more lines)" }
                puts "INFO: ══════════════════════════════════════════════════"
            } else { puts "WARNING: Command file not found: $cmd_file" }
            # Generate wrapper script even in test mode (for review)
            set _work_dir "$run_dir/work/$::flow_type/$node_name/run"
            file mkdir $_work_dir
            set _tool_name [expr {[info exists sta(tool,name)] ? $sta(tool,name) : "tempus"}]
            set _log_file "$_work_dir/${node_name}.log"
            set _module_cmd ""
            set _tool_shell "tempus"
            catch {
                if {[info exists lsf(module,$_tool_name)]} { set _module_cmd $lsf(module,$_tool_name) }
                if {[info exists lsf(tool_shell,$_tool_name)]} { set _tool_shell $lsf(tool_shell,$_tool_name) }
            }
            set _wrapper "$_work_dir/launch_${stage_name}.csh"
            set _wf [open $_wrapper "w"]
            puts $_wf "#!/bin/csh -f"
            puts $_wf "# CBFlow tool launch wrapper — $::flow_type $stage_name"
            puts $_wf "# Generated: [clock format [clock seconds]]"
            if {$_module_cmd ne ""} { puts $_wf "$_module_cmd" }
            puts $_wf "$_tool_shell -f $cmd_file -output_log_file $_log_file"
            close $_wf
            catch { file attributes $_wrapper -permissions rwxr-xr-x }
            puts "INFO: Wrapper script: $_wrapper"
            # Show planned launch mode in test mode
            set _use_lsf false
            set _use_xterm false
            if {[info exists ::env(CBFLOW_BSUB_CMD)] && $::env(CBFLOW_BSUB_CMD) ne ""} {
                set _use_lsf true
            } elseif {[info exists flow(use_lsf)] && $flow(use_lsf) eq "true"} {
                set _use_lsf true
            } elseif {[info exists ::env(CBFLOW_USE_LSF)] && $::env(CBFLOW_USE_LSF) eq "1"} {
                set _use_lsf true
            }
            if {[info exists flow(use_xterm)] && $flow(use_xterm) eq "true"} {
                set _use_xterm true
            } elseif {[info exists ::env(CBFLOW_USE_XTERM)] && $::env(CBFLOW_USE_XTERM) eq "1"} {
                set _use_xterm true
            }
            if {$_use_lsf} {
                puts "INFO: \[TEST MODE\] Launch mode: LSF ([expr {$_use_xterm ? "interactive xterm" : "batch"}])"
            } elseif {$_use_xterm} {
                puts "INFO: \[TEST MODE\] Launch mode: xterm (local)"
            } else {
                puts "INFO: \[TEST MODE\] Launch mode: local execution"
            }
            puts "INFO: $stage_name run completed \[TEST MODE\]"
        } else {
            if {![file exists $cmd_file]} { puts "ERROR: Command file not found: $cmd_file"; exit 1 }
            set _work_dir "$run_dir/work/$::flow_type/$node_name/run"
            set _tool_name [expr {[info exists sta(tool,name)] ? $sta(tool,name) : "tempus"}]
            set _log_file "$_work_dir/${node_name}.log"
            set _module_cmd ""
            set _tool_shell "tempus"
            set _wrapper_shell "/bin/csh -f"
            catch {
                if {[info exists lsf(module,$_tool_name)]} { set _module_cmd $lsf(module,$_tool_name) }
                if {[info exists lsf(tool_shell,$_tool_name)]} { set _tool_shell $lsf(tool_shell,$_tool_name) }
                if {[info exists lsf(tool_wrapper_shell)]} { set _wrapper_shell $lsf(tool_wrapper_shell) }
            }
            set _wrapper "$_work_dir/launch_${stage_name}.csh"
            set _wf [open $_wrapper "w"]
            puts $_wf "#!$_wrapper_shell"
            puts $_wf "# CBFlow tool launch wrapper — $::flow_type $stage_name"
            puts $_wf "# Generated: [clock format [clock seconds]]"
            if {$_module_cmd ne ""} { puts $_wf "$_module_cmd" }
            puts $_wf "$_tool_shell -f $cmd_file -output_log_file $_log_file"
            close $_wf
            catch { file attributes $_wrapper -permissions rwxr-xr-x }
            puts "INFO: Wrapper: $_wrapper"

            # Determine launch mode: LSF > XTERM > LOCAL
            set _use_lsf false
            set _use_xterm false
            if {[info exists ::env(CBFLOW_BSUB_CMD)] && $::env(CBFLOW_BSUB_CMD) ne ""} {
                set _use_lsf true
            } elseif {[info exists flow(use_lsf)] && $flow(use_lsf) eq "true"} {
                set _use_lsf true
            } elseif {[info exists ::env(CBFLOW_USE_LSF)] && $::env(CBFLOW_USE_LSF) eq "1"} {
                set _use_lsf true
            }
            if {[info exists flow(use_xterm)] && $flow(use_xterm) eq "true"} {
                set _use_xterm true
            } elseif {[info exists ::env(CBFLOW_USE_XTERM)] && $::env(CBFLOW_USE_XTERM) eq "1"} {
                set _use_xterm true
            }

            # Resolve xterm settings
            set _xterm "xterm"
            set _geom "200x50"
            catch { set _xterm $lsf(xterm,command) }
            catch { set _geom $lsf(xterm,geometry) }

            if {$_use_lsf} {
                if {[info exists ::env(CBFLOW_BSUB_CMD)] && $::env(CBFLOW_BSUB_CMD) ne ""} {
                    set bsub_cmd $::env(CBFLOW_BSUB_CMD)
                } else {
                    # Build bsub from config
                    set _qtype "M"
                    catch { set _qtype $lsf(flow_mapping,$::flow_type,$stage_name) }
                    set _mem "16GB"; set _cpu "8"; set _time "4:00"
                    catch { set _mem $lsf(queue_types,$_qtype,memory) }
                    catch { set _cpu $lsf(queue_types,$_qtype,cpu) }
                    catch { set _time $lsf(queue_types,$_qtype,runtime_limit) }
                    set _bsub "bsub"
                    set _queue_name "normal"
                    set _project ""
                    set _affinity ""
                    catch { set _bsub $lsf(bsub,command) }
                    catch { set _queue_name $lsf(bsub,queue) }
                    catch { set _project $lsf(bsub,project) }
                    catch { set _affinity $lsf(bsub,affinity) }
                    set bsub_cmd "$_bsub"
                    if {$_project ne ""} { append bsub_cmd " -P $_project" }
                    append bsub_cmd " -J cbflow_${::flow_type}_${stage_name}"
                    if {$_use_xterm} { append bsub_cmd " -Is" }
                    append bsub_cmd " -q $_queue_name -n $_cpu -W $_time"
                    append bsub_cmd " -R \"rusage\[mem=$_mem\]"
                    if {$_affinity ne ""} { append bsub_cmd " $_affinity" }
                    append bsub_cmd "\""
                    append bsub_cmd " -o $_work_dir/lsf_${node_name}_%J.log"
                    append bsub_cmd " -e $_work_dir/lsf_${node_name}_%J.err"
                }
                if {$_use_xterm} {
                    # LSF + xterm: submit to LSF, opens xterm on compute node
                    set _launch_target "$_xterm -geometry $_geom -title \"CBFlow $::flow_type $stage_name\" -e $_wrapper"
                    puts "INFO: Submitting via LSF (xterm): $bsub_cmd $_launch_target"
                    if {[catch {exec {*}$bsub_cmd $_xterm -geometry $_geom -title "CBFlow $::flow_type $stage_name" -e $_wrapper} result]} {
                        puts "ERROR: LSF submit failed: $result"; exit 1
                    }
                } else {
                    # LSF batch: submit wrapper directly
                    puts "INFO: Submitting via LSF (batch): $bsub_cmd $_wrapper"
                    if {[catch {exec {*}$bsub_cmd $_wrapper} result]} { puts "ERROR: LSF submit failed: $result"; exit 1 }
                }
                puts $result
            } elseif {$_use_xterm} {
                # Local xterm: opens xterm window running wrapper locally
                puts "INFO: Launching in xterm: $_xterm -geometry $_geom -e $_wrapper"
                exec $_xterm -geometry $_geom -title "CBFlow $::flow_type $stage_name" -e $_wrapper &
            } else {
                # Local execution in current terminal
                puts "INFO: Executing locally: $_wrapper"
                if {[catch {exec $_wrapper} result]} { puts "ERROR: $stage_name failed: $result"; exit 1 }
                puts $result
            }
            puts "INFO: $stage_name run completed"
        }
    }
    "validate" {
        puts "INFO: $stage_name validate..."
        if {$test_mode} {
            puts "INFO: \[TEST MODE\] Validation skipped"
        } else {
            puts "INFO: $stage_name validation passed"
        }
        puts "INFO: $stage_name validate completed"
    }
    "finish" {
        puts "INFO: $stage_name finish..."
        set finish_file "$run_dir/work/$::flow_type/$node_name/run/${stage_name}_finish.timestamp"
        file mkdir [file dirname $finish_file]
        set fh [open $finish_file "w"]
        puts $fh "Completed: [clock format [clock seconds]]"
        close $fh
        puts "INFO: $stage_name finish completed"
    }
    "dynamic" {
        # Dynamic timing: resolve MMMC scenarios and run per-scenario timing
        puts "INFO: $stage_name dynamic — resolving MMMC scenarios..."

        set mmmc_config_file "$::env(CONFIG_ROOT)/flow/$::env(FLOW_CONFIG_VERSION)/mmmc_config.tcl"
        if {[file exists $mmmc_config_file]} { source $mmmc_config_file }

        set setup_scenarios {}
        set hold_scenarios {}

        if {[info exists sta(mmmc,setup_scenarios)] && $sta(mmmc,setup_scenarios) ne ""} {
            set setup_scenarios $sta(mmmc,setup_scenarios)
        } elseif {[info exists mmmc_scenario_sets] && [array exists mmmc_scenario_sets]} {
            set sset [expr {[info exists sta(mmmc,scenario_set)] ? $sta(mmmc,scenario_set) : "sta_signoff"}]
            if {$sset ne "custom" && [info exists mmmc_scenario_sets($sset)]} {
                array set _ss $mmmc_scenario_sets($sset)
                if {[info exists _ss(scenarios)]} { set setup_scenarios $_ss(scenarios) }
            }
        }
        if {[info exists sta(mmmc,hold_scenarios)] && $sta(mmmc,hold_scenarios) ne ""} {
            set hold_scenarios $sta(mmmc,hold_scenarios)
        }

        set all_scenarios [lsort -unique [concat $setup_scenarios $hold_scenarios]]
        if {[llength $all_scenarios] == 0} {
            set all_scenarios {func_ss_0p76v_rcmax_150c func_ff_0p84v_rcmin_m40c}
        }

        puts "INFO: MMMC scenarios to run ([llength $all_scenarios]):"
        puts "INFO:   Setup: $setup_scenarios"
        puts "INFO:   Hold:  $hold_scenarios"

        set _work_dir "$run_dir/work/$::flow_type/$node_name/run"
        file mkdir $_work_dir
        file mkdir "$run_dir/reports/sta"

        set _scenario_handler "$::env(FLOW_DIR)/cmds/STA/cadence/tempus/$_tool_ver/timing_scenario_handler.tcl"

        foreach scenario $all_scenarios {
            puts "INFO: ── Scenario: $scenario ──"
            if {$test_mode} {
                if {[file exists $_scenario_handler]} {
                    catch {exec tclsh $_scenario_handler $scenario $run_dir} result
                    puts $result
                } else {
                    puts "INFO: \[TEST MODE\] Scenario $scenario — creating stubs"
                    set rpt [open "$run_dir/reports/sta/timing_${scenario}_summary.rpt" "w"]
                    puts $rpt "# Test mode: $scenario"
                    puts $rpt "Setup WNS: 0.000ns  Hold WNS: 0.000ns"
                    close $rpt
                }
            } else {
                if {[file exists $_scenario_handler]} {
                    if {[catch {exec tclsh $_scenario_handler $scenario $run_dir} result]} {
                        puts "ERROR: Scenario $scenario failed: $result"; exit 1
                    }
                    puts $result
                } else {
                    puts "ERROR: Scenario handler not found: $_scenario_handler"; exit 1
                }
            }
        }
        puts "INFO: $stage_name dynamic completed — [llength $all_scenarios] scenarios processed"
    }
    default {
        set scenario $subnode_name
        puts "INFO: $stage_name scenario: $scenario"

        # Source mmmc_config
        set _mmmc_cfg "$::env(CONFIG_ROOT)/flow/$::env(FLOW_CONFIG_VERSION)/mmmc_config.tcl"
        if {[file exists $_mmmc_cfg]} { source $_mmmc_cfg }

        if {![info exists analysis_views($scenario)]} {
            puts "ERROR: Scenario '$scenario' not found in analysis_views"
            exit 1
        }
        array set _sv $analysis_views($scenario)

        # Write scenario context
        set _work_dir "$run_dir/work/$::flow_type/$node_name/run"
        file mkdir $_work_dir
        file mkdir "$run_dir/reports/sta"

        set _ctx "$_work_dir/${scenario}_context.tcl"
        set _fh [open $_ctx "w"]
        puts $_fh "set ::scenario_name \"$scenario\""
        puts $_fh "set ::CORNER \"$_sv(corner)\""
        puts $_fh "set ::MODE \"$_sv(mode)\""
        puts $_fh "set ::VOLTAGE \"$_sv(voltage)\""
        puts $_fh "set ::TEMPERATURE \"$_sv(temperature)\""
        puts $_fh "set ::RC_CORNER \"$_sv(rc_corner)\""
        puts $_fh "set ::LIB_SET \"$_sv(lib_set_ref)\""
        puts $_fh "set ::DESIGN_NAME \"$flow(design_name)\""
        set _sdc_dir "$run_dir/work/$::flow_type/sdc1/sdc"
        puts $_fh "set ::SDC_FILE \"$_sdc_dir/$_sv(constraint_file)\""
        set _spef_manifest "$_work_dir/../setup/spef_manifest.tcl"
        if {[file exists $_spef_manifest]} {
            source $_spef_manifest
            if {[info exists spef_map($_sv(rc_corner))]} {
                puts $_fh "set ::SPEF_FILE \"$spef_map($_sv(rc_corner))\""
            }
        }
        close $_fh

        set cmd_file "$::env(FLOW_DIR)/cmds/STA/cadence/tempus/$_tool_ver/timing_scenario_tempus.tcl"

        if {$test_mode} {
            puts "INFO: \[TEST MODE\] Scenario $scenario"
            puts "INFO:   Corner=$_sv(corner) Mode=$_sv(mode) Voltage=$_sv(voltage) Temp=$_sv(temperature)"
            set rpt [open "$run_dir/reports/sta/timing_${scenario}_summary.rpt" "w"]
            puts $rpt "# Test mode: $scenario"
            puts $rpt "Setup WNS: 0.000ns  Hold WNS: 0.000ns"
            close $rpt
            puts "INFO: $stage_name scenario $scenario completed \[TEST MODE\]"
        } else {
            set _tool_name [expr {[info exists sta(tool,name)] ? $sta(tool,name) : "tempus"}]
            set _log_file "$_work_dir/${scenario}.log"
            set _module_cmd ""
            set _tool_shell "tempus"
            set _wrapper_shell "/bin/csh -f"
            catch {
                if {[info exists lsf(module,$_tool_name)]} { set _module_cmd $lsf(module,$_tool_name) }
                if {[info exists lsf(tool_shell,$_tool_name)]} { set _tool_shell $lsf(tool_shell,$_tool_name) }
                if {[info exists lsf(tool_wrapper_shell)]} { set _wrapper_shell $lsf(tool_wrapper_shell) }
            }
            set _wrapper "$_work_dir/launch_${scenario}.csh"
            set _wf [open $_wrapper "w"]
            puts $_wf "#!$_wrapper_shell"
            puts $_wf "setenv CBFLOW_SCENARIO $scenario"
            if {$_module_cmd ne ""} { puts $_wf "$_module_cmd" }
            puts $_wf "$_tool_shell -f $cmd_file -log $_log_file"
            close $_wf
            catch { file attributes $_wrapper -permissions rwxr-xr-x }
            if {[catch {exec $_wrapper_shell $_wrapper} result]} {
                puts "ERROR: Scenario $scenario failed: $result"
                exit 1
            }
            puts $result
            puts "INFO: $stage_name scenario $scenario completed"
        }
    }
}
