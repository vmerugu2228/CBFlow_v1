// Export netlist - Wed Jun 10 09:52:43 IST 2026
module cpu_core (); endmodule
