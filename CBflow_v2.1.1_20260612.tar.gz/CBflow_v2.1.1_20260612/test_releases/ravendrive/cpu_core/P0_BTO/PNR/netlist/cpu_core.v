// Export netlist - Wed Jun 10 09:53:48 IST 2026
module cpu_core (); endmodule
