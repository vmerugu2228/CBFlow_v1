// Export netlist - Wed Jun 10 09:55:10 IST 2026
module cpu_core (); endmodule
