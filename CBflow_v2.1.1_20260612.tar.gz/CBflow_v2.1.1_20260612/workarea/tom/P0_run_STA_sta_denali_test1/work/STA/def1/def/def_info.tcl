set def_info(timestamp) "Wed Jun 10 09:56:09 IST 2026"
set def_info(status) "loaded"
