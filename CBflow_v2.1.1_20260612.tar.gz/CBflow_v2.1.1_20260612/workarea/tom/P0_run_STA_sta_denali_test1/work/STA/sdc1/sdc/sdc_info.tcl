set sdc_info(timestamp) "Wed Jun 10 09:56:09 IST 2026"
set sdc_info(status) "loaded"
