#!/bin/csh -f
# CBflow tool launch wrapper — reporting
# Generated: Wed Jun 10 09:56:19 IST 2026
tempus -files /Users/vmerugu/projects/CBflow_clone/workarea/tom/P0_run_STA_sta_denali_test1/work/STA/reporting1/run/reporting1.tempus.tcl -log /Users/vmerugu/projects/CBflow_clone/workarea/tom/P0_run_STA_sta_denali_test1/work/STA/reporting1/run/reporting1.log
