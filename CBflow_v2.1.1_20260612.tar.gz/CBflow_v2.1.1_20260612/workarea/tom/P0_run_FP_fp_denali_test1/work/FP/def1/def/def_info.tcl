set def_info(timestamp) "Thu Jun 11 22:54:17 IST 2026"
set def_info(status) "loaded"
