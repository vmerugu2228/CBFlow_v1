#!/bin/csh -f
# CBflow tool launch wrapper — floorplan
# Generated: Thu Jun 11 22:54:23 IST 2026
innovus -files /Users/vmerugu/projects/CBflow_clone/workarea/tom/P0_run_FP_fp_denali_test1/work/FP/floorplan1/run/floorplan1.innovus.tcl -log /Users/vmerugu/projects/CBflow_clone/workarea/tom/P0_run_FP_fp_denali_test1/work/FP/floorplan1/run/floorplan1.log
