#!/bin/csh -f
# CBflow tool launch wrapper — export_data
# Generated: Thu Jun 11 22:54:30 IST 2026
innovus -files /Users/vmerugu/projects/CBflow_clone/workarea/tom/P0_run_FP_fp_denali_test1/work/FP/export_data1/run/export_data1.innovus.tcl -log /Users/vmerugu/projects/CBflow_clone/workarea/tom/P0_run_FP_fp_denali_test1/work/FP/export_data1/run/export_data1.log
