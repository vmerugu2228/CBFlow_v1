array set manifest {
    flow     "FP"
    design   "tom"
    netlist  "/Users/vmerugu/projects/CBflow_clone/workarea/tom/P0_run_FP_fp_denali_test1/work/FP/export_data1/outputs/tom.v"
    def      "/Users/vmerugu/projects/CBflow_clone/workarea/tom/P0_run_FP_fp_denali_test1/work/FP/export_data1/outputs/tom.def"
    sdc      "/Users/vmerugu/projects/CBflow_clone/workarea/tom/P0_run_FP_fp_denali_test1/work/FP/export_data1/outputs/tom.sdc"
}
