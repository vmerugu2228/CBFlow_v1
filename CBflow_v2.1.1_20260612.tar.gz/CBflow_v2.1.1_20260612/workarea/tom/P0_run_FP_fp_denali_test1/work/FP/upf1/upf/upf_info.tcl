set upf_info(timestamp) "Thu Jun 11 22:54:17 IST 2026"
set upf_info(status) "loaded"
