#!/bin/csh -f
# CBflow tool launch wrapper — init_design
# Generated: Thu Jun 11 22:54:20 IST 2026
innovus -files /Users/vmerugu/projects/CBflow_clone/workarea/tom/P0_run_FP_fp_denali_test1/work/FP/init_design1/run/init_design1.innovus.tcl -log /Users/vmerugu/projects/CBflow_clone/workarea/tom/P0_run_FP_fp_denali_test1/work/FP/init_design1/run/init_design1.log
