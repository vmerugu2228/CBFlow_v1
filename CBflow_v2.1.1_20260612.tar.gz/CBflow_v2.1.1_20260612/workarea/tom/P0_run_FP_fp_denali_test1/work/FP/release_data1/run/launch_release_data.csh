#!/bin/csh -f
# CBflow tool launch wrapper — release_data
# Generated: Thu Jun 11 22:54:33 IST 2026
innovus -files /Users/vmerugu/projects/CBflow_clone/workarea/tom/P0_run_FP_fp_denali_test1/work/FP/release_data1/run/release_data1.innovus.tcl -log /Users/vmerugu/projects/CBflow_clone/workarea/tom/P0_run_FP_fp_denali_test1/work/FP/release_data1/run/release_data1.log
