#!/bin/csh -f
# CBflow tool launch wrapper — powerplan
# Generated: Thu Jun 11 22:54:27 IST 2026
innovus -files /Users/vmerugu/projects/CBflow_clone/workarea/tom/P0_run_FP_fp_denali_test1/work/FP/powerplan1/run/powerplan1.innovus.tcl -log /Users/vmerugu/projects/CBflow_clone/workarea/tom/P0_run_FP_fp_denali_test1/work/FP/powerplan1/run/powerplan1.log
