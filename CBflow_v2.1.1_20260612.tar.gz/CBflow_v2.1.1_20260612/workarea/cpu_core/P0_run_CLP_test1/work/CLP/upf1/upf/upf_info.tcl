set upf_info(timestamp) "Wed Jun 10 09:57:04 IST 2026"
set upf_info(status) "loaded"
