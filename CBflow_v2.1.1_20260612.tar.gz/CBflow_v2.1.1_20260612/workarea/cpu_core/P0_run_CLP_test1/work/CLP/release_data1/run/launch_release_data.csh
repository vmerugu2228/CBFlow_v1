#!/bin/csh -f
# CBflow tool launch wrapper — release_data
# Generated: Wed Jun 10 09:57:11 IST 2026
vc_lp_shell -f /Users/vmerugu/projects/CBflow_clone/PD/cmds/CLP/synopsys/vc_lp/v1.0.0/release_data_vc_lp.tcl -log /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_CLP_test1/work/CLP/release_data1/run/release_data1.log
