#!/bin/csh -f
# CBflow tool launch wrapper — reporting
# Generated: Wed Jun 10 09:55:56 IST 2026
tempus -files /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_STA_tempus_test1/work/STA/reporting1/run/reporting1.tempus.tcl -log /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_STA_tempus_test1/work/STA/reporting1/run/reporting1.log
