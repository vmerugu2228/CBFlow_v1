set def_info(timestamp) "Wed Jun 10 09:55:46 IST 2026"
set def_info(status) "loaded"
