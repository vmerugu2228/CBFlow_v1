set netlist_info(timestamp) "Wed Jun 10 09:55:46 IST 2026"
set netlist_info(status) "loaded"
