#!/bin/csh -f
# CBflow tool launch wrapper — release_data
# Generated: Wed Jun 10 09:56:00 IST 2026
tempus -files /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_STA_tempus_test1/work/STA/release_data1/run/release_data1.tempus.tcl -log /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_STA_tempus_test1/work/STA/release_data1/run/release_data1.log
