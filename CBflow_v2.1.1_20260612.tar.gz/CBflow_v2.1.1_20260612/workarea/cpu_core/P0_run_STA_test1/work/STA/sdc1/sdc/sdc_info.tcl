set sdc_info(timestamp) "Fri Jun 12 09:21:59 IST 2026"
set sdc_info(mode_count) 0
