set def_info(timestamp) "Fri Jun 12 09:21:59 IST 2026"
set def_info(status) "loaded"
