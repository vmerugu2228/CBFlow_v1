#!/bin/csh -f
# CBflow tool launch wrapper — lvs
# Generated: Fri Jun 12 10:00:12 IST 2026
calibre /Users/vmerugu/projects/CBflow_clone/PD/cmds/PV/mentor/calibre/v1.0.0/lvs_calibre.tcl |& tee /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_PV_PV_calibre_test1/work/PV/lvs1/run/lvs1.log
