// Export netlist - Fri Jun 12 17:14:44 IST 2026
module cpu_core (); endmodule
