#!/bin/csh -f
# CBflow tool launch wrapper — synthesis
# Generated: Fri Jun 12 17:14:21 IST 2026
fc_shell -f /Users/vmerugu/projects/CBflow_clone/PD/cmds/SYNTH_PNR/synopsys/fc/v1.0.0/synthesis_fc.tcl -output_log_file /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_SYNTH_PNR_test1/work/SYNTH_PNR/synthesis1/run/synthesis1.log
