#!/bin/csh -f
# CBflow tool launch wrapper — power_analysis
# Generated: Wed Jun 10 09:58:03 IST 2026
voltus -files /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_EMIR_voltus_test1/work/EMIR/power_analysis1/run/power_analysis1.voltus.tcl -log /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_EMIR_voltus_test1/work/EMIR/power_analysis1/run/power_analysis1.log
