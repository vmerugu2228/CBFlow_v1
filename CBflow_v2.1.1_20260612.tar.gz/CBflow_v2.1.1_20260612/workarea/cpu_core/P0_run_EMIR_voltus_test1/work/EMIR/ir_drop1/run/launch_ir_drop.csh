#!/bin/csh -f
# CBflow tool launch wrapper — ir_drop
# Generated: Wed Jun 10 09:58:06 IST 2026
voltus -files /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_EMIR_voltus_test1/work/EMIR/ir_drop1/run/ir_drop1.voltus.tcl -log /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_EMIR_voltus_test1/work/EMIR/ir_drop1/run/ir_drop1.log
