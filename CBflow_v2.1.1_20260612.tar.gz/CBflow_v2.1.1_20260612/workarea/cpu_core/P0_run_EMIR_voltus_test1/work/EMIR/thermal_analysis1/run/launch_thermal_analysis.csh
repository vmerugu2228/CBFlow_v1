#!/bin/csh -f
# CBflow tool launch wrapper — thermal_analysis
# Generated: Wed Jun 10 09:58:09 IST 2026
voltus -files /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_EMIR_voltus_test1/work/EMIR/thermal_analysis1/run/thermal_analysis1.voltus.tcl -log /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_EMIR_voltus_test1/work/EMIR/thermal_analysis1/run/thermal_analysis1.log
