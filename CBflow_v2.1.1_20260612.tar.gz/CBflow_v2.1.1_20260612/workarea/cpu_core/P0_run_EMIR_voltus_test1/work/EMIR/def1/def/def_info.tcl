set def_info(timestamp) "Wed Jun 10 09:57:59 IST 2026"
set def_info(status) "loaded"
