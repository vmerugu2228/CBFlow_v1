set spef_info(timestamp) "Wed Jun 10 09:57:59 IST 2026"
set spef_info(status) "loaded"
