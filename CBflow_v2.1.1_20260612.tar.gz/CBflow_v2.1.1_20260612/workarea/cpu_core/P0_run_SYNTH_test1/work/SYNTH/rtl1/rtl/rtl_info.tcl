set rtl_info(timestamp) "2026-06-12 17:22:31"
set rtl_info(status) "loaded"
