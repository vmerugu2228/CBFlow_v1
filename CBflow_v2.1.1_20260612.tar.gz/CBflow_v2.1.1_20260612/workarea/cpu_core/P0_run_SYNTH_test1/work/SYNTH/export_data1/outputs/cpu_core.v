// Export netlist - Fri Jun 12 17:22:45 IST 2026
module cpu_core (); endmodule
