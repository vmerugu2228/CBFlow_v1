set upf_info(timestamp) "2026-06-12 17:22:31"
set upf_info(status) "loaded"
