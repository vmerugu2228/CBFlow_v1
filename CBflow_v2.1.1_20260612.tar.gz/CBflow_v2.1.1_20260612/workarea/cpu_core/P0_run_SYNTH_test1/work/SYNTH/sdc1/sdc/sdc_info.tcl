set sdc_info(timestamp) "2026-06-12 17:22:31"
set sdc_info(status) "loaded"
