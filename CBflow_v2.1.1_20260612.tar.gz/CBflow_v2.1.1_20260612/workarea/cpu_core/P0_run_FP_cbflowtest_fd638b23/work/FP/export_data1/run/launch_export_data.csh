#!/bin/csh -f
# CBflow tool launch wrapper — export_data
# Generated: Thu Jun 11 22:59:07 IST 2026
fc_shell -f /Users/vmerugu/projects/CBflow_clone/PD/cmds/FP/synopsys/fc/v1.0.0/export_data_fc.tcl -output_log_file /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_FP_cbflowtest_fd638b23/work/FP/export_data1/run/export_data1.log
