// Export netlist - Thu Jun 11 22:59:07 IST 2026
module cpu_core (); endmodule
