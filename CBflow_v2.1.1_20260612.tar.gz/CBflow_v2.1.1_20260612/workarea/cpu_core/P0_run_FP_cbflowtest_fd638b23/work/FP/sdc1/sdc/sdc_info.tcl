set sdc_info(timestamp) "Thu Jun 11 22:58:54 IST 2026"
set sdc_info(status) "loaded"
