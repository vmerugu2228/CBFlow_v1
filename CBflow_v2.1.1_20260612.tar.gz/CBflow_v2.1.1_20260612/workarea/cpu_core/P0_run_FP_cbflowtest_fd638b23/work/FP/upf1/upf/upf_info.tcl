set upf_info(timestamp) "Thu Jun 11 22:58:54 IST 2026"
set upf_info(status) "loaded"
