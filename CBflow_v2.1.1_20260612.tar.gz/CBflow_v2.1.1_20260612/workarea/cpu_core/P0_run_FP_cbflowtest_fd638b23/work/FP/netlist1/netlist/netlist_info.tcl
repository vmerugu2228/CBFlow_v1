set netlist_info(timestamp) "Thu Jun 11 22:58:54 IST 2026"
set netlist_info(status) "loaded"
