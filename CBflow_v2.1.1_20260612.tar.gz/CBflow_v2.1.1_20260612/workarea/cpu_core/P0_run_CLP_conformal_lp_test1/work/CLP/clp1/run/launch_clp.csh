#!/bin/csh -f
# CBflow tool launch wrapper — clp
# Generated: Wed Jun 10 09:57:24 IST 2026
conformal_lp -dofile /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_CLP_conformal_lp_test1/work/CLP/clp1/run/clp1.conformal_lp.tcl -logfile /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_CLP_conformal_lp_test1/work/CLP/clp1/run/clp1.log
