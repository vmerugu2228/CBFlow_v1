set power_spec_info(timestamp) "Wed Jun 10 09:57:20 IST 2026"
set power_spec_info(status) "loaded"
