#!/bin/csh -f
# CBflow tool launch wrapper — release_data
# Generated: Wed Jun 10 09:57:27 IST 2026
conformal_lp -dofile /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_CLP_conformal_lp_test1/work/CLP/release_data1/run/release_data1.conformal_lp.tcl -logfile /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_CLP_conformal_lp_test1/work/CLP/release_data1/run/release_data1.log
