set sdc_info(timestamp) "Wed Jun 10 09:58:19 IST 2026"
set sdc_info(mode_count) 0
