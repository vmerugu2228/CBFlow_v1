set netlist_info(timestamp) "Wed Jun 10 09:58:19 IST 2026"
set netlist_info(status) "loaded"
