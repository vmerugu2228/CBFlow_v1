#!/bin/csh -f
# CBflow tool launch wrapper — release_data
# Generated: Wed Jun 10 09:58:32 IST 2026
pt_shell -f /Users/vmerugu/projects/CBflow_clone/PD/cmds/STA/synopsys/pt/v1.0.0/release_data_pt.tcl -output_log_file /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_STA_from_run_test/work/STA/release_data1/run/release_data1.log
