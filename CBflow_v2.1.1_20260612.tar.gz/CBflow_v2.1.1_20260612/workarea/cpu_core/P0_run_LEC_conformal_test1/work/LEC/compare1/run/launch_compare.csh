#!/bin/csh -f
# CBflow tool launch wrapper — compare
# Generated: Wed Jun 10 09:56:51 IST 2026
conformal -dofile /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_LEC_conformal_test1/work/LEC/compare1/run/compare1.conformal.tcl -logfile /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_LEC_conformal_test1/work/LEC/compare1/run/compare1.log
