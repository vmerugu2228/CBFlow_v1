#!/bin/csh -f
# CBflow tool launch wrapper — release_data
# Generated: Wed Jun 10 09:56:55 IST 2026
conformal -dofile /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_LEC_conformal_test1/work/LEC/release_data1/run/release_data1.conformal.tcl -logfile /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_LEC_conformal_test1/work/LEC/release_data1/run/release_data1.log
