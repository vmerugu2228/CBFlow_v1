#!/bin/csh -f
# CBflow tool launch wrapper — export_data
# Generated: Fri Jun 12 09:21:04 IST 2026
fc_shell -f /Users/vmerugu/projects/CBflow_clone/PD/cmds/PNR/synopsys/fc/v1.0.0/export_data_fc.tcl -output_log_file /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_PNR_test1/work/PNR/export_data1/run/export_data1.log
