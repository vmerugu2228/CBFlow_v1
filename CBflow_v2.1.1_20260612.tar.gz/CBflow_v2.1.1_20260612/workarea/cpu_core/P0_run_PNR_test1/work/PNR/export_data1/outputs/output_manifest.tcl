array set manifest {
    flow     "PNR"
    design   "cpu_core"
    netlist  "/Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_PNR_test1/work/PNR/export_data1/outputs/cpu_core.v"
    def      "/Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_PNR_test1/work/PNR/export_data1/outputs/cpu_core.def"
    sdc      "/Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_PNR_test1/work/PNR/export_data1/outputs/cpu_core.sdc"
}
