// Export netlist - Fri Jun 12 09:21:04 IST 2026
module cpu_core (); endmodule
