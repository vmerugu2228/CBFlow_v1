set netlist_info(timestamp) "Fri Jun 12 09:20:37 IST 2026"
set netlist_info(status) "loaded"
