set sdc_info(timestamp) "Wed Jun 10 09:58:41 IST 2026"
set sdc_info(mode_count) 0
