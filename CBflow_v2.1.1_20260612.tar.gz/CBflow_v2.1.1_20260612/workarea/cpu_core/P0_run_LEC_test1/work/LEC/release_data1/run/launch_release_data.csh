#!/bin/csh -f
# CBflow tool launch wrapper — release_data
# Generated: Fri Jun 12 09:22:28 IST 2026
conformal -dofile /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_LEC_test1/work/LEC/release_data1/run/release_data1.conformal.tcl -logfile /Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_LEC_test1/work/LEC/release_data1/run/release_data1.log
