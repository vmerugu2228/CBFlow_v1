#!/usr/bin/env tclsh
# ═══════════════════════════════════════════════════════════════════════════════
# CBFlow - Consolidated Config for LEC compare1 (compare1_default)
# Generated: Fri Jun 12 09:22:22 IST 2026
# Description: Main configs sourced, overrides expanded with validation
# ═══════════════════════════════════════════════════════════════════════════════

# Environment setup
if {[info exists ::env(FLOW_DIR)]} {
    set FLOW_DIR $::env(FLOW_DIR)
} else {
    set FLOW_DIR "/Users/vmerugu/projects/CBflow_clone/PD"
}
if {[info exists ::env(RUN_DIR)]} {
    set RUN_DIR $::env(RUN_DIR)
} else {
    set RUN_DIR "/Users/vmerugu/projects/CBflow_clone/workarea/cpu_core/P0_run_LEC_test1"
}
if {[info exists ::env(PROJECT_VERSION)]} {
    set PROJECT_VERSION $::env(PROJECT_VERSION)
} else {
    set PROJECT_VERSION "v1.0.0"
}
if {[info exists ::env(FLOW_VERSION)]} {
    set FLOW_VERSION $::env(FLOW_VERSION)
} else {
    set FLOW_VERSION "v1.0.0"
}
if {[info exists ::env(TECH_VERSION)]} {
    set TECH_VERSION $::env(TECH_VERSION)
} else {
    set TECH_VERSION "v1.0.0"
}
if {[info exists ::env(TECH_NAME)]} {
    set TECH_NAME $::env(TECH_NAME)
} else {
    set TECH_NAME "gf_22nm"
}
if {[info exists ::env(TOOL_VERSION)]} {
    set TOOL_VERSION $::env(TOOL_VERSION)
} else {
    set TOOL_VERSION "v1.0.0"
}

global pnr project tech flow

puts "INFO: Loading consolidated config for LEC compare1 (compare1_default)"

# ═══════════════════════════════════════════════════════════════════════════════
# MAIN CONFIGURATION FILES (SOURCED)
# ═══════════════════════════════════════════════════════════════════════════════

# Source cbflow_init_config
if {[file exists "$FLOW_DIR/config/project/ravendrive/v1.0.0/cbflow_init_config.tcl"]} {
    puts "INFO: Loading cbflow_init_config: $FLOW_DIR/config/project/ravendrive/v1.0.0/cbflow_init_config.tcl"
    source "$FLOW_DIR/config/project/ravendrive/v1.0.0/cbflow_init_config.tcl"
} else {
    puts "WARNING: cbflow_init_config not found: $FLOW_DIR/config/project/ravendrive/v1.0.0/cbflow_init_config.tcl"
}

# Source project_config
if {[file exists "$FLOW_DIR/config/project/ravendrive/v1.0.0/ravendrive_config.tcl"]} {
    puts "INFO: Loading project_config: $FLOW_DIR/config/project/ravendrive/v1.0.0/ravendrive_config.tcl"
    source "$FLOW_DIR/config/project/ravendrive/v1.0.0/ravendrive_config.tcl"
} else {
    puts "WARNING: project_config not found: $FLOW_DIR/config/project/ravendrive/v1.0.0/ravendrive_config.tcl"
}

# Source team_config
if {[file exists "$FLOW_DIR/config/project/ravendrive/v1.0.0/team_config.tcl"]} {
    puts "INFO: Loading team_config: $FLOW_DIR/config/project/ravendrive/v1.0.0/team_config.tcl"
    source "$FLOW_DIR/config/project/ravendrive/v1.0.0/team_config.tcl"
} else {
    puts "WARNING: team_config not found: $FLOW_DIR/config/project/ravendrive/v1.0.0/team_config.tcl"
}

# Source technology_config
if {[file exists "$FLOW_DIR/config/tech/gf_22nm/v1.0.0/tech_config.tcl"]} {
    puts "INFO: Loading technology_config: $FLOW_DIR/config/tech/gf_22nm/v1.0.0/tech_config.tcl"
    source "$FLOW_DIR/config/tech/gf_22nm/v1.0.0/tech_config.tcl"
} else {
    puts "WARNING: technology_config not found: $FLOW_DIR/config/tech/gf_22nm/v1.0.0/tech_config.tcl"
}

# Source lib_config
if {[file exists "$FLOW_DIR/config/tech/gf_22nm/v1.0.0/lib_config_P0.tcl"]} {
    puts "INFO: Loading lib_config: $FLOW_DIR/config/tech/gf_22nm/v1.0.0/lib_config_P0.tcl"
    source "$FLOW_DIR/config/tech/gf_22nm/v1.0.0/lib_config_P0.tcl"
} else {
    puts "WARNING: lib_config not found: $FLOW_DIR/config/tech/gf_22nm/v1.0.0/lib_config_P0.tcl"
}

# Source flow_config
if {[file exists "$FLOW_DIR/config/flow/v1.0.0/flow_config.tcl"]} {
    puts "INFO: Loading flow_config: $FLOW_DIR/config/flow/v1.0.0/flow_config.tcl"
    source "$FLOW_DIR/config/flow/v1.0.0/flow_config.tcl"
} else {
    puts "WARNING: flow_config not found: $FLOW_DIR/config/flow/v1.0.0/flow_config.tcl"
}

# Source node_config_LEC
if {[file exists "$FLOW_DIR/config/flow/v1.0.0/node_configs/LEC_config.tcl"]} {
    puts "INFO: Loading node_config_LEC: $FLOW_DIR/config/flow/v1.0.0/node_configs/LEC_config.tcl"
    source "$FLOW_DIR/config/flow/v1.0.0/node_configs/LEC_config.tcl"
} else {
    puts "WARNING: node_config_LEC not found: $FLOW_DIR/config/flow/v1.0.0/node_configs/LEC_config.tcl"
}

# Source mmmc_config
if {[file exists "$FLOW_DIR/config/project/ravendrive/v1.0.0/mmmc_config.tcl"]} {
    puts "INFO: Loading mmmc_config: $FLOW_DIR/config/project/ravendrive/v1.0.0/mmmc_config.tcl"
    source "$FLOW_DIR/config/project/ravendrive/v1.0.0/mmmc_config.tcl"
} else {
    puts "WARNING: mmmc_config not found: $FLOW_DIR/config/project/ravendrive/v1.0.0/mmmc_config.tcl"
}

# Source user_config
if {[file exists "$RUN_DIR/setup/user_config.tcl"]} {
    puts "INFO: Loading user_config: $RUN_DIR/setup/user_config.tcl"
    source "$RUN_DIR/setup/user_config.tcl"
} else {
    puts "WARNING: user_config not found: $RUN_DIR/setup/user_config.tcl"
}


# ═══════════════════════════════════════════════════════════════════════════════
# DERIVED VARIABLES (engine-generated from project + tech configs)
# ═══════════════════════════════════════════════════════════════════════════════

# Active track and VT (from project_config)
set tech(track) $project(track_variant)
set tech(vt_flavors_loaded) $project(vt_flavors)

# ── Resolve active metal stack into flat tech() vars ──
if {[info exists project(metal_stack)] && $project(metal_stack) ne ""} {
    set _ms $project(metal_stack)

    # Tech LEF for active metal stack + track
    if {[info exists tech($_ms,$project(track_variant),lef_tech)]} {
        set tech(lef_tech) $tech($_ms,$project(track_variant),lef_tech)
    }

    # Metal stack properties
    foreach _var {metal_count metal_layers metal_stack_full tech_file min_routing_layer max_routing_layer clock_routing_layer_min clock_routing_layer_max pg_strap_layers pg_strap_secondary pg_ring_layer_h pg_ring_layer_v via_layers metal_fill_min_density metal_fill_max_density tluplus_map gds_layer_map_file antenna_rule_file signal_em_constraint_file stream_files_for_merge} {
        if {[info exists tech($_ms,$_var)]} {
            set tech($_var) $tech($_ms,$_var)
        }
    }

    # RC parasitic flat aliases
    foreach _corner {rc_max rc_typ rc_min rc_max_cworst} {
        foreach _fmt {tluplus nxtgrd qrc} {
            if {[info exists tech(rcx,$_ms,$_corner,$_fmt)]} {
                set tech(rcx,$_corner,$_fmt) $tech(rcx,$_ms,$_corner,$_fmt)
            }
        }
    }
}

# tech(lib_root) alias for backward compat with command files
if {[info exists project(lib_root)]} { set tech(lib_root) $project(lib_root) }

puts "INFO: Consolidated configuration loading complete for LEC compare1 (compare1_default)"
